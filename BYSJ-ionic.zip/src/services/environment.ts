export const environment = {
    // 是否生产模式
    production: false,
    // 加载提示语
    loadingText: "正在加载,请稍候...",
    // 本地接口地址
    server: "http://127.0.0.1:3018/",
    // 接口超时时间
    timeout: 60 * 1000,
    // sidebar  or   topnav
    layout: "sidebar",
    
    pageSize: 10
  };
  