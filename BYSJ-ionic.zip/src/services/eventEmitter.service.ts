import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class EventEmitterService {
    // 定义监听刷新事件
    public refreshPage:any;

    constructor(){
        this.refreshPage = new EventEmitter();
    }
}