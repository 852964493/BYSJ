import { Component, ViewChild } from '@angular/core';

import { Events, MenuController, Nav, Platform } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';

import { Storage } from '@ionic/storage';

import { AboutPage } from '../pages/about/about';
// import { AccountPage } from '../pages/account/account';
import { LoginPage } from '../pages/login/login';
import { MapPage } from '../pages/map/map';
// import { SignupPage } from '../pages/signup/signup';
import { TabsPage } from '../pages/tabs-page/tabs-page';
import { SchedulePage } from '../pages/schedule/schedule';
import { SpeakerListPage } from '../pages/speaker-list/speaker-list';
// import { SupportPage } from '../pages/support/support';
import { EventEmitterService } from "../services/eventEmitter.service";
import { ConferenceData } from '../providers/conference-data';
import { UserData } from '../providers/user-data';

export interface PageInterface {
  title: string;
  name: string;
  component: any;
  icon: string;
  logsOut?: boolean;
  index?: number;
  tabName?: string;
  tabComponent?: any;
}

@Component({
  templateUrl: 'app.template.html',
  providers: [EventEmitterService]
})
export class ConferenceApp {
  @ViewChild(Nav) nav: Nav;
  // 默认显示页面
  public rootPage: any;

  appPages: PageInterface[] = [
    { title: 'Schedule', name: 'TabsPage', component: TabsPage, tabComponent: SchedulePage, index: 0, icon: 'calendar' },
    { title: 'Speakers', name: 'TabsPage', component: TabsPage, tabComponent: SpeakerListPage, index: 1, icon: 'contacts' },
    { title: 'Map', name: 'TabsPage', component: TabsPage, tabComponent: MapPage, index: 2, icon: 'map' },
    { title: 'About', name: 'TabsPage', component: TabsPage, tabComponent: AboutPage, index: 3, icon: 'information-circle' }
  ];
  // loggedInPages: PageInterface[] = [
  // { title: 'Account', name: 'AccountPage', component: AccountPage, icon: 'person' },
  // { title: 'Support', name: 'SupportPage', component: SupportPage, icon: 'help' },
  // { title: 'Logout', name: 'TabsPage', component: TabsPage, icon: 'log-out', logsOut: true }
  // ];
  // loggedOutPages: PageInterface[] = [
  // { title: 'Login', name: 'LoginPage', component: LoginPage, icon: 'log-in' },
  // { title: 'Support', name: 'SupportPage', component: SupportPage, icon: 'help' },
  // { title: 'Signup', name: 'SignupPage', component: SignupPage, icon: 'person-add' }
  // ];

  constructor(
    public events: Events,
    public userData: UserData,
    public menu: MenuController,
    public platform: Platform,
    public confData: ConferenceData,
    public storage: Storage,
    public splashScreen: SplashScreen
  ) {
    // 默认打开登录页面
    this.rootPage = LoginPage;

  }

}
