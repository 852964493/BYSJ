import { Component } from '@angular/core';
import { NavParams } from 'ionic-angular';
import { Http } from '@angular/http';
import { environment } from "../../services/environment";

@Component({
  selector: 'page-session-detail',
  templateUrl: 'session-detail.html'
})
export class SessionDetailPage {
  // segment
  public segment: any = '1';
  // 学生ID
  public studentId: any;
  // 任务书信息
  public taskInfo: any = {};

  constructor(
    public navParams: NavParams,
    public http: Http
  ) {
    // 获取学生ID
    this.studentId = this.navParams.data;
    // 获取任务书信息
    this.getTask();
  }
  // 获取任务书
  getTask() {
    let that = this;
    let postBody: any = {
      where: {
        StudentId: this.studentId
      }
    }
    this.http.post(environment.server + 'api/v1/tasklists/view', postBody).map(res => res.json()).subscribe(body => {
      if (body.data) {
        that.taskInfo = body.data;
      }
    })
  }
}
