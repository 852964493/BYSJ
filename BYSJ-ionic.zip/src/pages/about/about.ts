import { Component  } from '@angular/core';
import { NavController, Nav } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { ActionSheetController } from 'ionic-angular';
import { LoginPage } from "../login/login";
import { SignupPage } from "../signup/signup";

@Component({
  selector: 'page-about',
  templateUrl: 'about.html'
})
export class AboutPage {
  // 用户名
  public userName:any;
  // 最近登录时间
  public loginTime:any;

  constructor(
    public storage:Storage,
    public nav: Nav,
    public navCtrl: NavController,
    public actionsheetCtrl: ActionSheetController
  ) { 
    // 用户名
    this.storage.get('UserName').then(UserName => {
      this.userName = UserName;
    })
    // 最近登录时间
    this.storage.get('updatedAt').then(updatedAt => {
      this.loginTime = updatedAt;
    })
  }
  // ActionSheet
  showActionSheet() {
    let actionSheet = this.actionsheetCtrl.create({
      title: '操作',
      buttons: [
        {
          text: '修改密码',
          icon: 'key',
          handler: ()=> {
            this.navCtrl.push(SignupPage);
          }
        },
        {
          text: '退出',
          icon: 'paper-plane',
          role: 'destructive',
          handler: ()=> {
            // 退出登录清空storage
            this.storage.remove('token');
            this.storage.remove('Role');
            this.storage.remove('UserId');
            this.storage.remove('PassWord');
            this.storage.remove('UserName');
            this.storage.remove('updatedAt');
            this.nav.setRoot(LoginPage);
          }
        },
        {
          text: '取消',
          icon: 'undo'
        }
      ]
    })
    actionSheet.present();
  }
}
