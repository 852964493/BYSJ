import { Component } from '@angular/core';
import { NavParams, NavController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { Http } from '@angular/http';
import { environment } from "../../services/environment";
import { EventEmitterService } from "../../services/eventEmitter.service";

@Component({
  selector: 'page-schedule-filter',
  templateUrl: 'schedule-filter.html'
})
export class ScheduleFilterPage {
  // 登录权限
  public role: any;
  // 学生ID
  public studentId: any;
  // 学生信息
  public studentInfo: any = {};
  // 详细信息
  public detailInfo: any

  constructor(
    public http: Http,
    public storage: Storage,
    public navParams: NavParams,
    public navCtrl: NavController,
    public eventService: EventEmitterService
  ) {
    let that = this;
    // 获取信息
    this.detailInfo = this.navParams.data;
    // 登录信息权限
    this.storage.get('Role').then(Role => {
      that.role = Role;
      if (Role == 'user') {
        // 获取学生ID
        that.storage.get('UserId').then(UserId => {
          that.studentId = UserId;
          that.getStudent();
        })
      }
    });
  }
  // 根据学生ID获取学生信息
  getStudent() {
    let that = this;
    let postBody: any = {
      where: {
        StudentId: this.studentId
      }
    }
    this.http.post(environment.server + 'api/v1/studentlists/view', postBody).map(res => res.json()).subscribe(body => {
      if (body.data) {
        that.studentInfo = body.data;
      }
    })
  }
  // 选择题目-student
  select() {
    this.editTitleStatus();
    this.editStudentStatus();
  }
  // 修改题目状态-student
  editTitleStatus() {
    let that = this;
    let postBody: any = {
      where: {
        TitleId: this.detailInfo.TitleId
      },
      values: {
        TitleStatus: "1",
        StudentId: this.studentInfo.StudentId,
        StudentName: this.studentInfo.StudentName
      }
    }
    this.http.post(environment.server + 'api/v1/titlelists/edit', postBody).map(res => res.json()).subscribe(body => {
      if (body.isSuccess) {
        // 发射监听，刷新上一页数据
        that.eventService.refreshPage.emit('user');
      }
    })
  }
  // 修改学生选题状态-student
  editStudentStatus() {
    let that = this;
    let postBody: any = {
      where: {
        StudentId: this.studentInfo.StudentId,
      },
      values: {
        SelectStatus: "1",
      }
    }
    this.http.post(environment.server + 'api/v1/studentlists/edit', postBody).map(res => res.json()).subscribe(body => {
      if (body.isSuccess) {
        // 返回上一页刷新
        that.navCtrl.pop();
      }
    })
  }
  // 确认选题-teacher
  agree() {
    this.setTitleStatus();
    this.setStudentStatus();
  }
  // 确认题目状态-teacher
  setTitleStatus() {
    let that = this;
    let postBody: any = {
      where: {
        TitleId: this.detailInfo.TitleId
      },
      values: {
        TitleStatus: "2"
      }
    }
    this.http.post(environment.server + 'api/v1/titlelists/edit', postBody).map(res => res.json()).subscribe(body => {
      if (body.isSuccess) {
        that.eventService.refreshPage.emit('teach');
      }
    })
  }
  // 确认学生选题状态-teacher
  setStudentStatus() {
    let that = this;
    let postBody: any = {
      where: {
        StudentId: this.detailInfo.StudentId
      },
      values: {
        SelectStatus: "2",
        TitleId: this.detailInfo.TitleId,
        TitleName: this.detailInfo.TitleName
      }
    }
    this.http.post(environment.server + 'api/v1/studentlists/edit', postBody).map(res => res.json()).subscribe(body => {
      if (body.isSuccess) {
        that.navCtrl.pop();
      }
    })
  }
  // 取消选题-teacher
  disAgree() {
    this.celTitleStatus();
    this.celStudentStatus();
  }
  // 取消题目状态-teacher
  celTitleStatus() {
    let that = this;
    let postBody: any = {
      where: {
        TitleId: this.detailInfo.TitleId
      },
      values: {
        TitleStatus: "0",
        StudentId: "",
        StudentName: ""
      }
    }
    this.http.post(environment.server + 'api/v1/titlelists/edit', postBody).map(res => res.json()).subscribe(body => {
      if (body.isSuccess) {
        that.eventService.refreshPage.emit('teach');
      }
    })
  }
  // 取消学生选题状态-teacher
  celStudentStatus() {
    let that = this;
    let postBody: any = {
      where: {
        StudentId: this.detailInfo.StudentId
      },
      values: {
        SelectStatus: "0",
        TitleId: "",
        TitleName: ""
      }
    }
    this.http.post(environment.server + 'api/v1/studentlists/edit', postBody).map(res => res.json()).subscribe(body => {
      if (body.isSuccess) {
        that.navCtrl.pop();
      }
    })
  }
}
