import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Http } from '@angular/http';
import { Storage } from '@ionic/storage';
import { environment } from "../../services/environment";

@Component({
  selector: 'page-map',
  templateUrl: 'map.html'
})
export class MapPage {
  // 登录信息
  public role: any;
  // 学生信息Id
  public StudentId: any;
  // 学生信息
  public studentInfo: any = {};
  // 教师信息Id
  public TeacherId: any;
  // 教师信息
  public teacherInfo: any = {};
  // 关键字
  public isSetKeyWord: any = false;
  // 关键字
  public keyword: any;
  constructor(
    public storage: Storage,
    public http: Http,
    public navCtrl: NavController
  ) {
    // 登录信息权限
    this.storage.get('Role').then(Role => {
      this.role = Role;
    });
    // 用户信息Id
    this.storage.get('UserId').then(UserId => {
      if (this.role == 'user') {
        this.StudentId = UserId;
        this.getStudentInfo();
      } else if (this.role == 'teach') {
        this.TeacherId = UserId;
        this.getTeacherInfo();
      }
    });
  }
  // 获取学生信息
  getStudentInfo() {
    let that = this;
    let StudentPost: any = {
      where: {
        StudentId: this.StudentId
      }
    }
    this.http.post(environment.server+'api/v1/studentlists/view', StudentPost).map(res => res.json()).subscribe(body => {
      if (body.data) {
        that.studentInfo = body.data;
      }
    })
  }
  // 获取教师信息
  getTeacherInfo() {
    let that = this;
    let TeacherPost: any = {
      where: {
        TeacherId: this.TeacherId
      }
    }
    this.http.post(environment.server+'api/v1/teacherlists/view', TeacherPost).map(res => res.json()).subscribe(body => {
      if (body.data) {
        that.teacherInfo = body.data;
      }
    })
  }
  // 编辑关键字
  editKeyWord() {
    this.isSetKeyWord = true;
  }
  // 设置关键字
  setKeyWord() {
    let that = this;
    let postBody: any = {
      where: {
        StudentId: this.StudentId
      },
      values: this.studentInfo
    }
    this.http.post(environment.server+'api/v1/studentlists/edit', postBody).map(res => res.json()).subscribe(body => {
      if (body.data) {
        that.isSetKeyWord = false;
        that.getStudentInfo();
      }
    })
  }
  // 取消编辑关键字
  // celKeyWord() {
  //   this.studentInfo.keyword = this.keyword;
  //   this.isSetKeyWord = false;
  // }
}
