import { Component } from '@angular/core';
import { NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { AboutPage } from '../about/about';
import { MapPage } from '../map/map';
import { SchedulePage } from '../schedule/schedule';
import { SpeakerListPage } from '../speaker-list/speaker-list';

@Component({
  templateUrl: 'tabs-page.html'
})
export class TabsPage {
  // 登录信息权限
  public role: any;

  tab1Root: any = SchedulePage;
  tab2Root: any = SpeakerListPage;
  tab3Root: any = MapPage;
  tab4Root: any = AboutPage;

  mySelectedIndex: number;

  constructor(
    public navParams: NavParams,
    public storage: Storage
  ) {
    // 登录信息
    this.storage.get('Role').then(Role => {
      this.role = Role;
    })
    this.mySelectedIndex = navParams.data.tabIndex || 0;
  }
}
