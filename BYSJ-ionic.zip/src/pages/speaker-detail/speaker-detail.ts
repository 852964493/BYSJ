import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { Http } from '@angular/http';
import { SessionDetailPage } from "../session-detail/session-detail";

@Component({
  selector: 'page-speaker-detail',
  templateUrl: 'speaker-detail.html'
})
export class SpeakerDetailPage {
  // 登录权限
  public role: any;
  // 学生ID
  public studentId: any;
  // 教师ID
  public teacherId: any;
  // 学生信息
  public studentInfo: any;

  constructor(
    public http: Http,
    public storage: Storage,
    public navCtrl: NavController,
    public navParams: NavParams
  ) {
    let that = this;
    // 获取信息
    this.studentInfo = this.navParams.data;
    // 登录信息权限
    this.storage.get('Role').then(Role => {
      that.role = Role;
    })
  }
  // 跳转到任务书页面
  showTask() {
    this.navCtrl.push(SessionDetailPage, this.studentInfo.StudentId);
  }
}
