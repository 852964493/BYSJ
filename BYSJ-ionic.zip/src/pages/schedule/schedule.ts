import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { Http } from '@angular/http';
import { environment } from "../../services/environment";
import { EventEmitterService } from "../../services/eventEmitter.service";
import { ScheduleFilterPage } from "../schedule-filter/schedule-filter";


@Component({
  selector: 'page-schedule',
  templateUrl: 'schedule.html'
})

export class SchedulePage {
  // 学生ID
  public studentId: any;
  // 学生信息
  public studentInfo: any = {};
  // 题目信息
  public titleInfo: any = {};
  // 教师ID
  public teacherId: any;
  // 登录权限
  public role: any;
  // 题目列表
  public titleLists: any = [];
  // 学生列表
  public studentLists: any = [];

  constructor(
    public http: Http,
    public storage: Storage,
    public navCtrl: NavController,
    public eventService: EventEmitterService
  ) {
    // 登录信息权限
    let that = this;
    this.storage.get('Role').then(Role => {
      that.role = Role;
      if (Role == 'user') {
        // 获取学生ID
        that.storage.get('UserId').then(UserId => {
          that.studentId = UserId;
          // 根据学生ID获取学生信息
          that.getStudent();
          // 根据学生ID获取题目信息
          that.getTitle();
        })
        // 获取教师ID
        that.storage.get('TeacherId').then(TeacherId => {
          that.teacherId = TeacherId;
          // 根据教师ID获取题目列表
          that.getTitleList();
        })
      } else if (Role == 'teach') {
        // 获取教师ID
        that.storage.get('UserId').then(UserId => {
          that.teacherId = UserId;
          // 根据教师ID获取学生列表
          that.getTitleList();
        })
      }
    });
    // 接收监听刷新事件,刷新当前页面
    this.eventService.refreshPage.subscribe((value: any) => {
      if (value == 'user') {
        // 刷新学生信息
        that.getStudent();
        // 刷新题目信息
        that.getTitle();
      } else if (value == 'teach') {
        // 刷新题目列表
        that.getTitleList();
      }
    })
  }

  // 根据学生ID获取题目信息
  getTitle() {
    let that = this;
    let postBody: any = {
      where: {
        StudentId: this.studentId
      }
    }
    this.http.post(environment.server + 'api/v1/titlelists/view', postBody).map(res => res.json()).subscribe(body => {
      if (body.data) {
        that.titleInfo = body.data;
      }
    })
  }
  // 根据学生ID获取学生信息
  getStudent() {
    let that = this;
    let postBody: any = {
      where: {
        StudentId: this.studentId
      }
    }
    this.http.post(environment.server + 'api/v1/studentlists/view', postBody).map(res => res.json()).subscribe(body => {
      if (body.data) {
        that.studentInfo = body.data;
      }
    })
  }
  // 根据教师ID获取题目列表
  getTitleList() {
    let that = this;
    this.titleLists = [];
    let postBody: any = {
      order: "TitleId ASC",
      where: {
        TeacherId: this.teacherId
      }
    }
    this.http.post(environment.server + 'api/v1/titlelists/views', postBody).map(res => res.json()).subscribe(body => {
      if (body.data) {
        that.titleLists = body.data;
      }
    })
  }
  // 取消选题
  celSelect() {
    this.celTitleStatus();
    this.celStudentStatus();
  }
  // 取消题目状态
  celTitleStatus() {
    let that = this;
    let postBody: any = {
      where: {
        TitleId: this.titleInfo.TitleId
      },
      values: {
        TitleStatus: "0",
        StudentId: "",
        StudentName: ""
      }
    }
    this.http.post(environment.server + 'api/v1/titlelists/edit', postBody).map(res => res.json()).subscribe(body => {
      if (body.isSuccess) {
        that.getTitleList();
      }
    })
  }
  // 取消学生选题状态
  celStudentStatus() {
    let that = this;
    let postBody: any = {
      where: {
        StudentId: this.studentId
      },
      values: {
        SelectStatus: "0",
      }
    }
    this.http.post(environment.server + 'api/v1/studentlists/edit', postBody).map(res => res.json()).subscribe(body => {
      if (body.isSuccess) {
        // 根据学生ID获取学生信息
        that.getStudent();
      }
    })
  }
  // 跳到详情页面
  showDetail(data: any) {
    this.navCtrl.push(ScheduleFilterPage, data);
  }
}
