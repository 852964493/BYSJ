'use strict';
module.exports = function (sequelize, DataTypes) {
    var TitleList = sequelize.define('titlelist', {
        Id: {
            type: DataTypes.INTEGER,                      // 数据类型
            allowNull: false,                             // 是否允许为空
            primaryKey: true,  
            autoIncrement: true                           // 自动递增
        },
        // 题目编号
        TitleId: {
            type: DataTypes.STRING(10),
            allowNull: false,
            primaryKey: true,                             // 是否为主键
            unique: {
                msg: '编号已存在！'
            }
        },
        // 题目
        TitleName: {
            type: DataTypes.STRING(30),
            allowNull: false,
            unique: {
                msg: '题目已存在！'
            }
        },
        // 题目详情
        TitleDetail: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        // 题目要求
        TitleRequire: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        // 选题人ID
        StudentId: {
            type: DataTypes.STRING(10),
        },
        // 选题人姓名
        StudentName: {
            type: DataTypes.STRING(20),
        },
        // 状态
        TitleStatus: {
            type: DataTypes.ENUM,
            allowNull: false,
            values: ['0','1', '2'],
            defaultValue: '0'
        },
        // 导师ID
        TeacherId: {
            type: DataTypes.STRING(10)
        },
        // 导师名
        TeacherName: {
            type: DataTypes.STRING(20)
        },
        // 导师系别
        TeacherDepartment: {
            type: DataTypes.STRING(10)
        }
    });
    return TitleList;
}