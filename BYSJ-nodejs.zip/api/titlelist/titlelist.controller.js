'use strict';
var async = require('async');
var TitleListService = require('./titlelist.service');
var util = require('../global/util');

// 普通列表
exports.views = function (req, res){
    TitleListService.views(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
}
// 分页列表
exports.list = function (req, res){
    TitleListService.list(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
}
// 单个查询
exports.view = function (req, res){
    TitleListService.view(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
}
// 新增
exports.add = function (req, res) {
    TitleListService.add(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
};
// 更新
exports.edit = function (req, res) {
    TitleListService.edit(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
};
// 删除
exports.del = function (req, res) {
    TitleListService.del(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
};