var db = require('../../sqldb');
var Notices = db.Notices;
var common = new require('../global/common.service')('Notices');

// 更新
exports.edit = function(body) {
    return db.sequelize.transaction(function(t) {
        return common.edit(body,t);
    })
}
// 查询
exports.view = function(body) {
    return db.sequelize.transaction(function(t) {
        return common.view(body,t);
    })
}