'use strict';
var async = require('async');
var NoticesService = require('./notices.service');
var util = require('../global/util');

// 更新
exports.edit = function (req, res) {
    NoticesService.edit(req.body).then(function (result) {
        return util.formatResult(null, result, res);
    }).catch(function (err) {
        return util.formatResult(err, null, res);
    });
};
// 查询
exports.view = function (req, res){
    NoticesService.view(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
}