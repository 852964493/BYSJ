'use strict';
module.exports = function (sequelize, DataTypes) {
    var Notices = sequelize.define('notice', {
        Id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true
        },
        // 公告详情
        NoticesDetail: {
            type: DataTypes.STRING(3000),
            allowNull: true
        }
    });
    return Notices;
}