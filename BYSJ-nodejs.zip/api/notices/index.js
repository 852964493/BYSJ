'use strict';
var express = require('express');
var router = express.Router();
var routerFilter = require('../global/router.filter');
routerFilter.extend(router, 'Notices', []);
var controller = require('./notices.controller');
var auth = require('../../auth/auth.service');

router.post('/edit',controller.edit);
router.post('/view',controller.view);

module.exports = router;