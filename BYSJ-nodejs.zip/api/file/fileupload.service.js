
var mutipart = require('connect-multiparty');
var express = require('express');
var config = require('../../config/environment');

var mutipartMiddeware = mutipart();
var app = express();
