'use strict';
module.exports = function (sequelize, DataTypes) {
    var TaskList = sequelize.define('tasklist', {
        Id: {
            type: DataTypes.INTEGER,                      // 数据类型
            allowNull: false,                             // 是否允许为空
            primaryKey: true,  
            autoIncrement: true                           // 自动递增
        },
        // 学生学号
        StudentId: {
            type: DataTypes.STRING(10),
            allowNull: false,
            primaryKey: true,      
            unique: {
                msg: '学号已存在！'
            }
        },
        // 学生姓名
        StudentName: {
            type: DataTypes.STRING(20),
            allowNull: false
        },
        // 设计概述-task one
        DesignSummary: {
            type: DataTypes.STRING(1500)
        },
        // 设计内容-task two 1
        DesignContent: {
            type: DataTypes.STRING(300)
        },
        // 研究内容-task two 2
        ResearchContent: {
            type: DataTypes.STRING(300)
        },
        // 实现功能web端-task two 3
        FunctionForPC: {
            type: DataTypes.STRING(300)
        },
        // 实现功能mobile端-task two 3
        FunctionForMobile: {
            type: DataTypes.STRING(300)
        },
        // 后期任务-task two 4
        LaterTask: {
            type: DataTypes.STRING(300)
        },
        // 最终提交-task two 5
        LastSumbit: {
            type: DataTypes.STRING(300)
        },
        // 系统需求分析-task three 1
        SystemAnalysis: {
            type: DataTypes.STRING(150)
        },
        // 系统设计-task three 2
        SystemDesign: {
            type: DataTypes.STRING(150)
        },
        // 技术准备-task three 3
        SkillReady: {
            type: DataTypes.STRING(150)
        },
        // 软件设计-task three 4
        SoftwareDesign: {
            type: DataTypes.STRING(150)
        },
        // 软件开发编程-task three 5
        SoftwareDevelop: {
            type: DataTypes.STRING(150)
        },
        // 软件测试-task three 6
        SoftwareTest: {
            type: DataTypes.STRING(150)
        },
        // 论文撰写-task three 7
        TitleWrite: {
            type: DataTypes.STRING(150)
        },
        // 论文初稿提交-task three 8
        TitleFristSumbit: {
            type: DataTypes.STRING(150)
        },
        // 论文修改-task three 9
        TitleEdit: {
            type: DataTypes.STRING(150)
        },
        // 论文答辩-task three 10
        TitleAnswer: {
            type: DataTypes.STRING(150)
        },
        // 论文成品提交-task three 11
        TitleLastSumbit: {
            type: DataTypes.STRING(150)
        },
        // 参考文献-task four
        Reference: {
            type: DataTypes.STRING(1000)
        }
    });
    return TaskList;
}