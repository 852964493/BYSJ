'use strict';

var crypto = require('crypto');

var validatePresenceOf = function(value) {
    return value && value.length;
};

module.exports = function(sequelize, DataTypes) {
    var User = sequelize.define('user', {
        //内码
        Id: {
            type: DataTypes.INTEGER,                      // 数据类型
            allowNull: false,                             // 是否允许为空
            primaryKey: true,  
            autoIncrement: true                           // 自动递增
        },
        //用户ID
        UserId: {
            type: DataTypes.STRING(10),
            allowNull: false,
            primaryKey: true,                             // 是否为主键
            unique: {
                msg: '系统号已存在'
            }
        },
        // 用户姓名
        UserName: {
            type: DataTypes.STRING(20),
            allowNull: false
        },
        // 密码
        PassWord: {
            type: DataTypes.STRING(16),
            allowNull: false
        },
        // 角色
        Role: {
            type: DataTypes.ENUM,
            allowNull: false,
            values: ['user','teach', 'admin'],
            //defaultValue: 'user'
        },
        // 最后一次登录时间
        LastLoginTime: DataTypes.DATE,
        // 是否允许登录
        Active: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        }
    }, {

    });
    return User;
};