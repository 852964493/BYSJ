'use strict';
var db = require('../../sqldb');
var userService = require('./user.service');
var util = require('../global/util');


// 登录
exports.passwordLogin = function(req, res) {
    userService.passwordLogin(req.body).then(function(result) {
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
}

// 用户新增
exports.register = function(req, res) {
    userService.register(req.body).then(function(result) {
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
}

// 用户列表
exports.list = function(req, res) {
    userService.list(req.body).then(function(result) {
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
}
// 更新
exports.edit = function (req, res) {
    userService.edit(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
};
// 删除
exports.del = function (req, res) {
    userService.del(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
};