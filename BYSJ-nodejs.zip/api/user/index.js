'use strict';
var express = require('express');
var router = express.Router();
var controller = require('./user.controller');
var routerFilter = require('../global/router.filter');
routerFilter.extend(router, 'User', []);

// 用户登录
router.post('/login', controller.passwordLogin);
// 用户新增
router.post('/register', controller.register);
router.post('/list', controller.list);
router.post('/edit', controller.edit);
router.post('/del', controller.del);

module.exports = router;
