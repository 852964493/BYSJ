var config = require('../../config/environment');

// 增删改除各个方法
module.exports = function (module) {
    // t = 事务一致性
    var db = require('../../sqldb')[module];
    return {
        // 分页列表
        list: function (body, t) {
            var pageSize = body.pageSize ? body.pageSize : config.pageSize;
            var pageIndex = body.pageIndex ? body.pageIndex : 1;
            var id = body.id;
            return db.findAll({
                where: body.where,
                attributes: [
                    [db.sequelize.fn('COUNT', db.sequelize.col(id)), 'count']
                ],
                transaction: t
            }).then(function (total) {
                return db.findAll({
                    offset: (pageIndex - 1) * pageSize,     // 跳到第几页
                    limit: pageSize,                        // 每页数据个数
                    attributes: body.attributes,
                    where: body.where,
                    order: body.order,
                    include: body.include,
                    transaction: t
                }).then(function (result) {
                    var isMore = 1;
                    if (result.length < pageSize) {
                        isMore = 0;
                    }
                    return {
                        pageIndex: pageIndex,
                        list: result,
                        isMore: isMore,
                        pageSize: pageSize,
                        total: total[0].dataValues.count
                    };
                });
            });
        },
        // 不分页列表
        views: function (body, t) {
            var searchbody;
            if (body.where && body.order) {
                searchbody = {
                    where: body.where,
                    order: body.order,
                    transaction: t
                }
            } else {
                searchbody = {
                    where: body,
                    transaction: t
                }
            }
            return db.findAll(searchbody).then(function (result) {
                return result;
            });
        },
        // 单个查询
        view: function (body, t) {
            return db.findOne({
                where: body.where,
                transaction: t
            }).then(function (result) {
                return result;
            });
        },
        // 新增
        add: function (body, t) {
            return db.create(body, {
                transaction: t
            }).then(function (result) {
                return result;
            })
        },
        // 编辑
        edit: function (body, t) {
            // delete body.values.createdAt;
            // 删除-重置更新时间
            delete body.values.updatedAt;
            delete body.values.deletedAt;
            return db.update(body.values, {
                where: body.where,
                transaction: t
            }).then(function (result) {
                return result;
            });
        },
        // 删除
        del: function (body, t) {
            return db.destroy({
                where: body,
                transaction: t
            });
        },

    }
};