var _ = require('lodash');
var auth = require('../../auth/auth.service');
var util = require('../global/util');

// 封装增删改除方法的接口地址
// things新增接口 = 127.0.0.1(本机地址):3018/api/v1/things(自定义表名)/add(自定义名称)
// things编辑接口 = 127.0.0.1(本机地址):3018/api/v1/things(自定义表名)/edit(自定义名称)
// things删除接口 = 127.0.0.1(本机地址):3018/api/v1/things(自定义表名)/del(自定义名称)
// things查询接口 = 127.0.0.1(本机地址):3018/api/v1/things(自定义表名)/view(自定义名称)
// things分页接口 = 127.0.0.1(本机地址):3018/api/v1/things(自定义表名)/list(自定义名称)
// things数据接口 = 127.0.0.1(本机地址):3018/api/v1/things(自定义表名)/views(自定义名称)

// module-数据库表名,exclude-排除的方法
exports.extend = function(router, module, exclude) {
    var Service = new require('../global/common.service')(module);
    var methods = ['view', 'views', 'add', 'edit', 'del', 'list'];
    if (exclude) {
        methods = _.difference(methods, exclude);
    }
    _.forEach(methods, function(item, key) {
        router.post('/base/admin/' + item, auth.hasRole(['admin']), function(req, res) {
            return Service[item](req.body).then(function(result) {
                return util.formatResult(null, result, res);
            }).catch(function(err) {
                return util.formatResult(err, null, res);
            });
        });
    });
}
