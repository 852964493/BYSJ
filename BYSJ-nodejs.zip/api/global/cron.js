var _ = require('lodash');
var db = require('../../sqldb');
var config = require('../../config/environment');
var moment = require('moment');
var request = require('request');
var URI = require('urijs');
var async = require('async');
var Promise = require("bluebird");
Promise.promisifyAll(require("request"));
var CronJob = require('cron').CronJob;
var kueClient = require('./kue');
var crypto = require('crypto');

var redis = require("redis");
var socketRedisClient = redis.createClient(config.socketRedis);
var emitter = require('socket.io-emitter')(socketRedisClient);

var util = require('./util');


module.exports = function () {
    var cron = new CronJob({
        cronTime: '* * * * * *',
        onTick: function () {
            // console.log('--------');
        },
        start: true
    });
}