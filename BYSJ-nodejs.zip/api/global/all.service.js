'use strict';

var _ = require('lodash');
var fs = require('fs');
var path = require('path');
var config = require('../../config/environment');
var svc = {};

var p = config.root + '/api';
var dirs = fs.readdirSync(p);

// 循环找出当前目录除了global外的所有.service.js文件
dirs.filter(function(file) {
	// indexOf()返回内容里面第一次出现的位置
		return (file.indexOf('.') !== 0) && (file !== 'global');
	})
	// dir-文件目录名, 循环找出dir目录下的.service.js文件
	.forEach(function(dir) {
		fs.readdirSync(p + '/' + dir).filter(function(file) {
			return (file.indexOf('.service.js') > 0);
		}).forEach(function(file) {
			// 取出service文件的头部名字
			var name = _.upperFirst(file.replace('.service.js', ''));
			svc[name] = require(p + '/' + dir + '/' + file);
		});
	});
// svc-交换虚拟路径
/* svc={
**	 User:{../../api/user/user.service.js},
**   Thing:{../../api/thing/thing.service.js}
** }
*/
module.exports = svc;