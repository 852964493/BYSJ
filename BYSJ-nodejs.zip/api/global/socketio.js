var config = require('../../config/environment');

var redis = require("redis");
var socketRedisClient = redis.createClient(config.socketRedis);
var emitter = require('socket.io-emitter')(socketRedisClient);

module.exports = function(socketio) {

    socketio.use(require('socketio-jwt').authorize({
        secret: config.secrets.session,
        handshake: true
    }));

    socketio.on('connection', function(socket) {
        // 把用户添加到一个房间，只有用户一个人
        socket.join(socket.decoded_token.username);
        socket.on('disconnect', function() {
            // 把用户离开房间
            socket.leave(socket.decoded_token.username);
        });

    });


    // setInterval(function() {
    // emitter.to('fengjk').emit('push', 'to fengjk message !');
    // emitter.emit('push', 'to all person message !');
    // }, 1000);
    // body...
}
