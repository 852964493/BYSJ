var db = require('../../sqldb');
var StudentList = db.StudentList;
var common = new require('../global/common.service')('StudentList');

// 普通列表
exports.views = function(body){
    return db.sequelize.transaction(function(t) {
        return common.views(body,t);
    })
}
// 分页列表
exports.list = function(body){
    return db.sequelize.transaction(function(t) {
        return common.list(body,t);
    })
}
// 查询学生
exports.view = function(body) {
    return db.sequelize.transaction(function(t) {
        return common.view(body,t);
    })
}
// 新增学生
exports.add = function(body) {
    return db.sequelize.transaction(function(t) {
        return common.add(body,t);
    })
}
// 更新学生
exports.edit = function(body) {
    return db.sequelize.transaction(function(t) {
        return common.edit(body,t);
    })
}
// 删除学生
exports.del = function(body) {
    return db.sequelize.transaction(function(t) {
        return common.del(body,t);
    })
}

















// exports.add = function(body) {
//     return db.sequelize.transaction(function(t) {
//         return StudentList.create(body,{
//             transaction: t
//         }).then(function(result){
//             return result;
//         });
//     });
// }