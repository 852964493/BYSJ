'use strict';
//var _ = require('lodash');
var async = require('async');
//var moment = require('moment');
//var config = require('../../config/environment');
//var validator = require('validator');
//var db = require('../../sqldb');
//var StudentList = db.StudentList;
//var svc = require('../global/all.service');
//var StudentListService = svc.studentlist;
var StudentListService = require('./studentlist.service');
var util = require('../global/util');

// 普通列表
exports.views = function (req, res){
    StudentListService.views(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
}
// 分页列表
exports.list = function (req, res){
    StudentListService.list(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
}
// 单个查询
exports.view = function (req, res){
    StudentListService.view(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
}
// 新增学生
exports.add = function (req, res) {
    StudentListService.add(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
};
// 更新学生
exports.edit = function (req, res) {
    StudentListService.edit(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
};
// 删除学生
exports.del = function (req, res) {
    StudentListService.del(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
};