'use strict';
module.exports = function (sequelize, DataTypes) {
    var StudentList = sequelize.define('studentlist', {
        Id: {
            type: DataTypes.INTEGER,
            allowNull: false,     
            primaryKey: true,                        
            autoIncrement: true                
        },
        // 学生年级
        StudentGrade: {
            type: DataTypes.STRING(4),
            allowNull: false
        },
        // 学生系别
        StudentDepartment: {
            type: DataTypes.STRING(10),
            allowNull: false
        },
        // 学生专业
        StudentMajor: {
            type: DataTypes.STRING(30),
            allowNull: false
        },
        // 学生学号
        StudentId: {
            type: DataTypes.STRING(10),
            allowNull: false,
            primaryKey: true,      
            unique: {
                msg: '学号已存在！'
            }
        },
        // 学生姓名
        StudentName: {
            type: DataTypes.STRING(20),
            allowNull: false
        },
        // 学生性别
        StudentSex: {
            type: DataTypes.STRING(2),
            allowNull: false
        },
        // 学生电话
        StudentNumber: {
            type: DataTypes.STRING(11),
            unique: {
                msg: '电话已存在！'
            }
        },
        // 学生邮箱
        StudentEmail: {
            type: DataTypes.STRING,
            allowNull: false,
            validate:{
                isEmail: true                   // 邮箱验证
            },
            unique: {
                msg: '邮箱已存在！'
            }
        },
        // 导师工号
        TeacherId: {
            type: DataTypes.STRING(4)
        },
        // 导师姓名
        TeacherName: {
            type: DataTypes.STRING(20)
        },
        // 导师性别
        TeacherSex: {
            type: DataTypes.STRING(2)
        },
        // 导师系别
        TeacherDepartment: {
            type: DataTypes.STRING(10)
        },
        // 导师电话
        TeacherNumber: {
            type: DataTypes.STRING(11)
        },
        // 导师邮箱
        TeacherEmail: {
            type: DataTypes.STRING(255),
            validate:{
                isEmail: true                   // 邮箱验证
            }
        },
        // 选题状态
        SelectStatus: {
            type: DataTypes.ENUM,
            values: ['0','1', '2'],
            defaultValue: '0'
        },
        // 题目编号
        TitleId: {
            type: DataTypes.STRING(10)
        },
        // 已选论文题目
        TitleName: {
            type: DataTypes.STRING(30)
        },
        // 论文关键字
        KeyWord: {
            type: DataTypes.STRING(200)
        },
        // 文件
        File: {
            type: DataTypes.STRING(255)
        },
        // 评阅状态
        ReadStatus: {
            type: DataTypes.ENUM,
            allowNull: false,
            values: ['0','1'],
            defaultValue: '0'
        },
        // 系统评分
        SystemScore: {
            type: DataTypes.STRING(3),
            validate: {
                max: 50,                  // 允许的最大值
                min: 0,                   // 允许的最小值
            }
        },
        // 论文评分
        TitleScore: {
            type: DataTypes.STRING(3),
            validate: {
                max: 50,                  // 允许的最大值
                min: 0,                   // 允许的最小值
            }
        },
        // 总分
        Score: {
            type: DataTypes.STRING(3),
            validate: {
                max: 100,                 // 允许的最大值
                min: 0,                   // 允许的最小值
            }
        },
        // 评分等级
        Level: {
            type: DataTypes.ENUM,
            allowNull: false,
            values: ['0','1', '2','3'],
            defaultValue: '0'
        },
        // 毕业年份
        Graduation: {
            type: DataTypes.STRING(4),
        }
    }, {
        // paranoid: true,
        // engine: 'MYISAM'
    });
    return StudentList;
}