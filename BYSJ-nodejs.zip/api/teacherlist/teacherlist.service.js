var db = require('../../sqldb');
var TeacherList = db.TeacherList;
var common = new require('../global/common.service')('TeacherList');

// 普通列表
exports.views = function(body){
    return db.sequelize.transaction(function(t) {
        return common.views(body,t);
    })
}
// 分页列表
exports.list = function(body){
    return db.sequelize.transaction(function(t) {
        return common.list(body,t);
    })
}
// 查询
exports.view = function(body) {
    return db.sequelize.transaction(function(t) {
        return common.view(body,t);
    })
}
// 新增
exports.add = function(body) {
    return db.sequelize.transaction(function(t) {
        return common.add(body,t);
    })
}
// 更新
exports.edit = function(body) {
    return db.sequelize.transaction(function(t) {
        return common.edit(body,t);
    })
}
// 删除
exports.del = function(body) {
    return db.sequelize.transaction(function(t) {
        return common.del(body,t);
    })
}
