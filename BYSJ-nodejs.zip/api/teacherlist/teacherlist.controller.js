'use strict';
var async = require('async');
var TeacherListService = require('./teacherlist.service');
var util = require('../global/util');

// 普通列表
exports.views = function (req, res){
    TeacherListService.views(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
}
// 分页列表
exports.list = function (req, res){
    TeacherListService.list(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
}
// 单个查询
exports.view = function (req, res){
    TeacherListService.view(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
}
// 新增
exports.add = function (req, res) {
    TeacherListService.add(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
};
// 更新
exports.edit = function (req, res) {
    TeacherListService.edit(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
};
// 删除
exports.del = function (req, res) {
    TeacherListService.del(req.body).then(function(result){
        return util.formatResult(null, result, res);
    }).catch(function(err) {
        return util.formatResult(err, null, res);
    });
};