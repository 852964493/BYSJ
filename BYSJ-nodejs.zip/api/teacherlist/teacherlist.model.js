'use strict';
module.exports = function (sequelize, DataTypes) {
    var TeacherList = sequelize.define('teacherlist', {
        Id: {
            type: DataTypes.INTEGER,                      // 数据类型
            allowNull: false,                             // 是否允许为空
            primaryKey: true,  
            autoIncrement: true                           // 自动递增
        },
        // 教师系别
        TeacherDepartment: {
            type: DataTypes.STRING(10),
            allowNull: false
        },
        // 教师ID
        TeacherId: {
            type: DataTypes.STRING(10),
            allowNull: false,
            primaryKey: true,                             // 是否为主键
            unique: {
                msg: '工号已存在！'
            }
        },
        // 教师姓名
        TeacherName: {
            type: DataTypes.STRING(20),
            allowNull: false
        },
        // 教师性别
        TeacherSex: {
            type: DataTypes.STRING(2),
            allowNull: false
        },
        // 教师电话
        TeacherNumber: {
            type: DataTypes.STRING(11),
            allowNull: false,
            unique: {
                msg: '电话已存在！'
            }
        },
        // 教师邮箱
        TeacherEmail: {
            type: DataTypes.STRING,
            allowNull: false,
            validate:{
                isEmail: true                   // 邮箱验证
            },
            unique: {
                msg: '邮箱已存在！'
            }
        }
    });
    return TeacherList;
}