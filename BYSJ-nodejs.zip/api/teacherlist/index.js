'use strict';
var express = require('express');
var router = express.Router();
var routerFilter = require('../global/router.filter');
routerFilter.extend(router, 'TeacherList', []);
var controller = require('./teacherlist.controller');
var auth = require('../../auth/auth.service');

router.post('/view',controller.view);
router.post('/views',controller.views);
router.post('/list',controller.list);
router.post('/add',controller.add);
router.post('/edit',controller.edit);
router.post('/del',controller.del);

module.exports = router;