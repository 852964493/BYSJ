'use strict';

// Development specific configuration
// ==================================
module.exports = {

    env: "development",

    // Server port
    port: process.env.PORT || 3018,

    domain: '127.0.0.1',

    kueWorkers: 10,

    pageSize: 10,

    // Secret for session, you will want to change this and make it an environment variable
    secrets: {
        session: 'node-server@2018',
        // 单位：秒 一个月
        expiresIn: 60 * 60 * 24 * 30,
        // 管理员登录超时  一个月
        adminExpiresIn: 60 * 60 * 24 * 30
    },

    // Sequelize connection opions
    sequelize: {
        database: 'nodejs',
        username: 'root',
        password: '',
        options: {
            host: '192.168.99.100',
            dialect: 'mysql',
            // 时间转换时从数据库得到的JavaScript时间。
            // 这个时区将应用于连接服务器的 NOW、CURRENT_TIMESTAMP或其它日期函数
            timezone: '+08:00',
            // 用于Sequelize日志打印的函数
            logging: function() {},
            define: {
                // 使用下划线，自动添加的字段会在数据段中使用“蛇型命名”规则，
                // 如：createdAt在数据库中的字段名会是created_at
                underscored: false,
                // 时间戳，启用该配置后会自动添加createdAt、updatedAt两个字段，
                // 分别表示创建和更新时间
                timestamps: true,
                // 虚拟删除。
                // 启用该配置后，数据不会真实删除，而是添加一个deletedAt属性
                paranoid: true
            }
        }
    },

    kue: {
        disableSearch: true,
        jobEvents: false,
        redis: {
            host: '192.168.99.100',
            port: "6379",
            db: 0
        }
    },

    commonRedis: {
        host: "192.168.99.100",
        port: "6379",
        db: 1
    },

    socketRedis: {
        host: "192.168.99.100",
        port: "6379",
        db: 2
    },

    seedDB: false
};