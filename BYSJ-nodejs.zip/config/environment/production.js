'use strict';

// Development specific configuration
// ==================================
module.exports = {

    env: "production",

    // Server port
    port: process.env.PORT || 3018,

    domain: '192.168.99.100',

    kueWorkers: 10,

    pageSize: 10,

    // Secret for session, you will want to change this and make it an environment variable
    secrets: {
        session: 'node-server@2018',
        // 单位：秒 一个月
        expiresIn: 60 * 60 * 24 * 30,
        // 管理员登录超时  一个月
        adminExpiresIn: 60 * 60 * 24 * 30
    },

    // Sequelize connection opions
    sequelize: {
        username: 'root',
        password: 'Legion@2017',
        database: 'node-server-production',
        options: {
            host: '192.168.99.100',
            port: 3308,
            dialect: 'mysql',
            timezone: '+08:00',
            logging: function() {},
            define: {
                underscored: false,
                timestamps: true,
                paranoid: true
            }
        }
    },

    kue: {
        disableSearch: true,
        jobEvents: false,
        redis: {
            host: "192.168.99.100",
            port: "6379",
            auth: "Legion@2017",
            db: 0
        }
    },

    commonRedis: {
        host: "192.168.99.100",
        port: "6379",
        password: "Legion@2017",
        db: 1
    },

    socketRedis: {
        host: "192.168.99.100",
        port: "6379",
        password: "Legion@2017",
        db: 2
    },

    seedDB: false
};