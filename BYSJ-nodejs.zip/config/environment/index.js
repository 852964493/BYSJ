'use strict';

var path = require('path');
var _ = require('lodash');
var fs = require('fs');

function requiredProcessEnv(name) {
    if (!process.env[name]) {
        throw new Error('You must set the ' + name + ' environment variable');
    }
    return process.env[name];
}

var rootPath = path.normalize(__dirname + '/../..');

// All configurations will extend these options
// ============================================
var all = {
  
    env: process.env.NODE_ENV,

    appName: "毕业设计管理系统",

    // Root path of server
    root: path.normalize(__dirname + '/../..'),

    // Server IP
    ip: process.env.IP || '0.0.0.0',

    // Should we populate the DB with sample data?
    seedDB: false,

    // List of user roles
    userRoles: ['user', 'teach', 'admin'],

};

// Export the config object based on the NODE_ENV
// ==============================================
module.exports = _.merge(
    all,
    require('./' + process.env.NODE_ENV + '.js') || {});