echo '============  git pull  ============';

git pull origin master;

echo '============  npm install  ============';

npm install;

echo '============  pm2 stop  ============';

pm2 stop process.json;

echo '============  pm2 delete  ============';

pm2 delete process.json;

echo '============  pm2 start  ============';

pm2 start process.json;

echo '============  finished  ============';