var crypto = require('crypto');

var result  = crypto.createHash('md5').update('xxx').digest('hex');

console.log(result);
