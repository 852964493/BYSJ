const { VM } = require('vm2');
var CronJob = require('cron').CronJob;

// const executor = require('../api/global/executor');

// console.log(executor);

var hello = function(name) {
    var promise = new Promise(function(resolve, reject) {
    	console.log(name);
    });
    return promise;
}

const vm = new VM({
    timeout: 1000,
    sandbox: {
        hello: hello
    }
});

var result = vm.run("hello('aa')");
console.log(typeof(result));