var fs = require('fs');
var path = require('path');
var rootPath = path.normalize(__dirname);

var execSql = function(sql) {
    var promise = new Promise(function(resolve, reject) {
        resolve({
            sql: sql,
            data: {
                age: 9,
                name: 'juno'
            }
        });
    });
    return promise;
};

fs.readFile(rootPath + '/str.js', 'utf8', (err, data) => {
    if (err) throw err;
    data = data.replace(/[\r\n]/g, "");
    console.log(data);
    eval(data);
});
