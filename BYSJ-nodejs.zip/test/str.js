execSql("数据库地址", "数据库类型（'mysql'|'sqlite'|'postgres'|'mssql'）", "连接账号", "连接密码", "需要执行sql", '抓取频率(单位秒)').then(function ('查询返回数据') {
    // 举例判断日期是否已经逾期，
    if (data.startDate > '2017-07-08') {
        sendAlert("通知类型('all'|'email'|'web'|'sms')", '通知模板id', '通知内容参数');
    } else {
        // 可以嵌套使用请求接口数据
        execHttp("接口地址", "请求类型('get'|'post'|'put'|'delete')", "请求自定义header", "请求参数", '抓取频率(单位秒)').then(function ("接口返回数据") {
            if (data.count > 10) {
                sendAlert("通知类型('all'|'email'|'web'|'sms')", '通知模板id', '通知内容参数');
            }
        });
    }
});

getProduct().then(function (data) {
    // if (data.start - ) {

    // }
});


execSql({
    database: "node-server-dev",
    username: "root",
    password: "",
    host: "127.0.0.1",
    dialect: "mysql",
    sql: "select * from products"
}).then(function (result) {
    console.log(result);
});

sendAlert({
    type: 'web,email',
    tid: "1",
    username: "juno",
    data: {
        name: "hello !~~这是自定义提示内容"
    }
});

execHttp({
    url: "http://127.0.0.1:3018/api/v1/users/login/password",
    method: "post",
    body: {
        "username": "juno",
        "password": "123456"
    }
}).then(function (result) {
    console.log(result);
});

execSoap({
    url: "http://10.88.115.89:8086/services/Email?wsdl",
    disableCache: false,
    method: "getMailInfoByBosid",
    body: {
        "mailbosid": "4889790",
        "logid": "fengjk"
    }
}).then(function (result) {
    console.log(result);
});


execHttp({
    url: "http://120.25.208.138:3018/api/v1/products/list",
    method: "post",
    body: {
        "pageIndex": 1,
        "pageSize": 10,
        "condictions": {
            "status": "ing"
        }
    }
}).then(function (result) {
    console.log(result);
    if (result.list[0].count < 100) {
        sendAlert({
            tid: '1',
            type: 'web',
            username: 'juno',
            data: {
                name: 'juno'
            }
        });
    }
});