var kue = require('kue'),
    queue = kue.createQueue({
        disableSearch: false,
        jobEvents: false,
        redis: {
            host: "120.25.208.138",
            port: "6379",
            auth: "Legion@2017",
            db: 0
        }
    });

queue.create('test', { id: "1111", "name": "juno" }).searchKeys(['id', 'name']).save(function(err) {
    console.log(err);
});