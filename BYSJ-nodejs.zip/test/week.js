var moment = require('moment');

for (var index = 1; index < 8; index++) {
    console.log(moment().subtract(index, 'days').format("YYYY-MM-DD"));
}