/**
 * Sequelize initialization module
 */
'use strict';

var path = require('path');
var config = require('../config/environment');
var Sequelize = require('sequelize');

/*  config.sequelize.database = mysql
 *  config.sequelize.username = root
 *  config.sequelize.password = ''
 */
var db = {
    Sequelize,
    sequelize: new Sequelize(config.sequelize.database, config.sequelize.username, config.sequelize.password, config.sequelize.options)
};
// 导入表模版
// Model
// db.Thing = db.sequelize.import('../api/thing/thing.model');
// user
db.User = db.sequelize.import('../api/user/user.model');
// 学生列表
db.StudentList = db.sequelize.import('../api/studentlist/studentlist.model');
// 教师列表
db.TeacherList = db.sequelize.import('../api/teacherlist/teacherlist.model');
// 题目列表
db.TitleList = db.sequelize.import('../api/titlelist/titlelist.model');
// 任务书列表
db.TaskList = db.sequelize.import('../api/tasklist/tasklist.model');
// 公告
db.Notices = db.sequelize.import('../api/notices/notices.model');
module.exports = db;