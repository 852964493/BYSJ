export const environment = {
  // 是否生产模式
  production: false,
  // 加载提示语
  loadingText: "正在加载,请稍候...",
  // 本地接口地址
  server: "http://127.0.0.1:3018/",
  // 预警平台
  //server: "http://120.25.208.138:3018/",
  // 场外交收
  //server: "http://otc-test.zhuwenda.com:8000/",
  // 接口超时时间
  timeout: 60 * 1000,
  // sidebar  or   topnav
  layout: "sidebar",
  
  pageSize: 10
};
