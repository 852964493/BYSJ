import { NgModule, OnInit } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './pages/global/layout/layout.component';
import { AuthGuardService } from './services/auth-guard.service';

const routes:Routes= [
  {
    path: '',
    loadChildren: './pages/login/login.module#LoginModule'
  },
  {
    path: 'pages',
    component: LayoutComponent,
    //canActivate: [AuthGuardService],
    children: [
      // {
      //   path: 'first',
      //   loadChildren: './pages/first/home.module#HomeModule'
      // },
      // {
      //   path: 'news',
      //   loadChildren: './pages/news/new.module#NewModule'
      // },
      {
        path: 'student',
        loadChildren: './pages/student/student.module#StudentModule'
      },
      {
        path: 'teacher',
        loadChildren: './pages/teacher/teacher.module#TeacherModule'
      },
      {
        path: 'manage',
        loadChildren: './pages/manage/manage.module#ManageModule'
      },
      {
        path: 'notices',
        loadChildren: './pages/notices/notice.module#NoticeModule'
      },
      {
        path: 'demoManage',
        loadChildren: './pages/demoManage/demo.module#DemoModule'
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule{
  
}
