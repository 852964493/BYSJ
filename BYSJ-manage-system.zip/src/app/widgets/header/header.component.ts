import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { environment } from '../../../environments/environment';
import { HeaderService } from './header.service';
import io from 'socket.io-client/dist/socket.io.js';
import { MissionService } from '../../services/mission.service';


@Component({
	selector: 'app-header',
	templateUrl: './header.component.html',
	styleUrls: ['./header.component.scss'],
	providers: [HeaderService]
})
export class AppHeaderComponent implements OnInit {
	public $ = window['$'];
	// 登录ID
	public userId: any;
	// 登录密码
	public passWord: any;
	// 原密码
	public originPassWord: any;
	// 新密码
	public newPassWord1: any;
	public newPassWord2: any;

	@Input() public layoutMode: String = "";
	@Input() public links: Array<any> = [];
	@Input() public currentUrl: String = "";
	@Input() public nav;
	@Input() public user;

	public server: String = environment.server;
	constructor(
		public router: Router,
		public headerService: HeaderService,
		public missionService: MissionService
	) {

	}
	ngOnInit() {
		let that = this;
		// 获取登录密码
		this.userId = sessionStorage.getItem('UserId');
		// 获取登录密码
		this.passWord = sessionStorage.getItem('PassWord');
		var token = sessionStorage.getItem('token');
		var socket = io(this.server, {
			'query': 'token=' + token
		});
		socket.on('connect', function () {
			console.log('socket连接成功')
		});

		socket.on("broadcast", (data: any) => {
			that.missionService.broadcast(data);
		}
		);
		socket.on("nodejs", (data: any) => {
			data = JSON.parse(data);
			window['swal']({
				type: "info",
				title: "毕设管理系统",
				text: data.content,
				html: true
			});
		}
		);
	}

	// 修改密码
	changePassWord() {
		let that = this;
		if (this.checkOriginPassWord()) {
			if (this.checknewPassWord()) {
				window["swal"]({
					title: "确定?",
					text: "确定要修改密码?",
					type: "info",
					confirmButtonText: "确认",
					confirmButtonColor: "#DD6B55",
					cancelButtonText: "取消",
					showCancelButton: true,
					closeOnConfirm: false,
					closeOnCancel: true,
					showLoaderOnConfirm: true
				}, function (isConfirm) {
					if (isConfirm) {
						that.headerService.changePassWord(that.userId, that.newPassWord2).subscribe(data => {
							if (data) {
								window['$']('#PasswordModel').modal('hide');
								window["swal"]("成功", "密码修改成功，请重新登录!", "success");
								sessionStorage.removeItem('token');
								sessionStorage.removeItem('Role');
								sessionStorage.removeItem('UserId');
								sessionStorage.removeItem('PassWord');
								sessionStorage.removeItem('UserName');
								sessionStorage.removeItem('updatedAt');
								that.router.navigateByUrl('');
							}
						})
					}
				})
			}
		}
	}
	// 判断原密码是否正确
	checkOriginPassWord() {
		if (this.originPassWord === this.passWord) {
			return true;
		} else {
			window["swal"]("提示", "原密码不正确", "info");
			return false
		}
	}
	// 判断新密码是否一致
	checknewPassWord() {
		if (this.newPassWord1 === this.newPassWord2) {
			return true;
		} else {
			window["swal"]("提示", "新密码不一致", "info");
			return false
		}
	}
	// 清空密码信息
	resetPassWordModel() {
		this.originPassWord = "";
		this.newPassWord1 = "";
		this.newPassWord2 = "";
	}
	// 注销清空session
	removeSession() {
		sessionStorage.removeItem('token');
		sessionStorage.removeItem('Role');
		sessionStorage.removeItem('UserId');
		sessionStorage.removeItem('PassWord');
		sessionStorage.removeItem('UserName');
		sessionStorage.removeItem('updatedAt');
		// this.router.navigateByUrl("pages/login");
		this.router.navigateByUrl('');
	}
	// 模版弹出
	toggleModel(modelId) {
		let id = '#' + modelId;
		this.$(id).modal('toggle');
	}
}
