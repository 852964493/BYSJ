import { HttpClientService } from '../../services/http-client.service';
import { Injectable } from '@angular/core';

@Injectable()
export class HeaderService {

  constructor(public httpClient: HttpClientService) {

  }
  // 修改密码
  changePassWord(userId, newPassword) {

    let postBody: any = {
      where: {
        UserId: userId
      },
      values: {
        PassWord: newPassword
      }
    }
    console.log(postBody)
    return this.httpClient.post('api/v1/users/edit', postBody);
  }
}
