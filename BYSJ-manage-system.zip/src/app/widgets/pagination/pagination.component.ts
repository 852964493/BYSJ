import { Component, OnInit, Input } from '@angular/core';
import * as _ from 'lodash';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss']
})
export class PaginationComponent{
	// @Input() pages;
	// @Input() changePage;
	// @Input() getList;
	// @Input() searchBody;

	constructor() { 

	}
}
