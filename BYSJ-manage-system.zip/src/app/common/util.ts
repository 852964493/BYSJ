import { Injectable } from '@angular/core';
import * as moment from "moment";
import * as _ from 'lodash'

@Injectable()
export class Util {
	setPage(total,pageSize,pageIndex) {
		let pages = [];
		var pagesCount = Math.ceil(total / pageSize);
		var start = pageIndex - 3;
		var end = pageIndex + 3;
		if (start <= 0) {
			start = 1;
			end = 6;
		}else{
			start = pageIndex - 2;
		}
		if (end > pagesCount) {
			end = pagesCount + 1;
			start = end - 5;
			if (start <= 0) {
				start = 1;
			}
		}
		pages = _.range(start, end);
		return pages;
	}
}
