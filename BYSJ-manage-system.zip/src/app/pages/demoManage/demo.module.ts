import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DemoRoutingModule } from './demo-routing.module';
import { DemoListComponent } from './list/list.component';
@NgModule({
	imports: [
		CommonModule,
		DemoRoutingModule
	],
	declarations: [DemoListComponent]
})
export class DemoModule { }
