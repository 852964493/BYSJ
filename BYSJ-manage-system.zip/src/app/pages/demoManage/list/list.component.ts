import { Component, OnInit } from '@angular/core';

import { DemoListService } from './list.service';
import * as moment from 'moment';
import * as _ from 'lodash'

import { MissionService } from '../../../services/mission.service';


@Component({
	selector: 'demo-list',
	templateUrl: './list.component.html',
	styleUrls: ['./list.component.scss'],
	providers: [DemoListService]
})
export class DemoListComponent {
	// backgroundColor="
	// rgba(255, 99, 132, 0.2)
	// rgba(54, 162, 235, 0.2)
	// rgba(255, 206, 86, 0.2)
	// rgba(75, 192, 192, 0.2)
	// rgba(153, 102, 255, 0.2)
	// rgba(255, 159, 64, 0.2)";
	// borderColor="
	// rgba(255,99,132,1)
	// rgba(54, 162, 235, 1)
	// rgba(255, 206, 86, 1) 
	// rgba(75, 192, 192, 1) 
	// rgba(153, 102, 255, 1) 
	// rgba(255, 159, 64, 1)";



	// public theRule: any = '0';
	// public selectRule: any = {};

	// addRule() {
	// 	this.selectRule = {};
	// 	this.selectRule.name = 'manual';
	// 	this.selectRule.type = 'manual';
	// 	this.selectRule.active = true;

	// 	this.theRule = "0";
	// }
}