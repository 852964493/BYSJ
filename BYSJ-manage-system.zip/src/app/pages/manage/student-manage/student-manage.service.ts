import { HttpClientService } from '../../../services/http-client.service';
import { Injectable } from '@angular/core';

@Injectable()
export class StudentManageService {
    constructor(public httpClient:HttpClientService) { 

    }
    // 获取学生列表
    getStudentList(searchBody){
        let postBody:any= {
            pageIndex: searchBody.PageIndex,
            pageSize: parseInt(searchBody.PageSize),
            order: "StudentId ASC",
            id: "StudentId",
            where:{
                StudentId:{
                    "$like": "%"+searchBody.StudentId+"%"
                },
                StudentGrade:{
                    "$like": "%"+searchBody.StudentGrade+"%"
                },
                StudentDepartment:{
                    "$like": "%"+searchBody.StudentDepartment+"%"
                },
                StudentMajor:{
                    "$like": "%"+searchBody.StudentMajor+"%"
                },
                TeacherName:{
                    "$like": "%"+searchBody.TeacherName+"%"
                },
                ReadStatus: {
                    "$like": "%"+searchBody.ReadStatus+"%"
                },
                SelectStatus: {
                    "$like": "%"+searchBody.SelectStatus+"%"
                },
                Level: {
                    "$like": "%"+searchBody.Level+"%"
                }
            }
        }
        return this.httpClient.post('api/v1/studentlists/list',postBody);
    }
    // 新增学生
    addStudent(addStudentModel){
        return this.httpClient.post('api/v1/studentlists/add',addStudentModel);
    }
    // 新增学生任务书
    addStudentTask(addStudentModel){
        let postBody:any= {
            StudentId: addStudentModel.StudentId,
            StudentName: addStudentModel.StudentName
        }
        return this.httpClient.post('api/v1/tasklists/add',postBody);
    }
    // 编辑学生信息
    editStudent(editstudentModel){
        let postBody:any={
            where:{
                Id: editstudentModel.Id
            },
            values:editstudentModel
        }
        return this.httpClient.post('api/v1/studentlists/edit',postBody);
    }
    // 删除学生
    delStudent(Id){
        let postBody:any= {
            Id: Id
        }
        return this.httpClient.post('api/v1/studentlists/del',postBody);
    }
    // 获取教师列表
    getTeacherList(teachSearch){
        let postBody:any= {
            pageIndex: teachSearch.PageIndex,
            pageSize: 10,
            order: "TeacherId ASC",
            id: "TeacherId",
            where:{
                TeacherName:{
                    "$like": "%"+teachSearch.TeacherName+"%"
                },
                TeacherDepartment:{
                    "$like": "%"+teachSearch.TeacherDepartment+"%"
                }
            }
        }
        return this.httpClient.post('api/v1/teacherlists/list',postBody);
    }
    // 导师分配
    selectTeach(item,teach){
        let postBody:any= {
            where:{
                Id: item.Id
            },
            values: {
                TeacherId: teach.TeacherId,
                TeacherName: teach.TeacherName,
                TeacherSex: teach.TeacherSex,
                TeacherDepartment: teach.TeacherDepartment,
                TeacherNumber: teach.TeacherNumber,
                TeacherEmail: teach.TeacherEmail
            }
        }
        return this.httpClient.post('api/v1/studentlists/edit',postBody);
    }
}
