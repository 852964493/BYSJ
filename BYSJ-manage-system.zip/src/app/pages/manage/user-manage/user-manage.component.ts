import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserManageService } from "./user-manage.service";
import { Util } from "../../../common/util";
import * as _ from 'lodash';

@Component({
  selector: 'app-user-manage',
  templateUrl: './user-manage.component.html',
  styleUrls: ['./user-manage.component.scss'],
  providers: [UserManageService]
})
export class UserManageComponent implements OnInit {
  // 全选
  public checkall:any= false;
  // 分页
  public pages: any = [];
  // 用户列表
  public userList:any;
  // 查询模版
  public searchBody:any= {
    UserId: "",
    Role: "",
    PageIndex: 1,
    PageSize: 10,
    Total: ""
  }
  // 新增模版
  public addUserModel:any= {
    Role: "",
    UserId: "",
    PassWord: "",
    UserName: ""
  }
  // 编辑信息
  public editUserModel:any= {};

  constructor(
    public userService:UserManageService,
    public util:Util
  ) {
    this.getUserList();
  }
  ngOnInit() {

  }
  // 获取教师列表
  getUserList(index?){
    let that = this;
    if (index) {
      this.searchBody.PageIndex = 1;
    }
    this.userService.getUserList(this.searchBody).subscribe(data=> {
      if (data) {
        that.userList = data.list;
        that.searchBody.Total = data.total;
        that.searchBody.PageSize = data.pageSize;
        that.searchBody.PageIndex = data.pageIndex;
        if (data.total) {
          that.pages = that.util.setPage(data.total,data.pageSize,data.pageIndex);
        }else{
          // 无数据返回空页
          that.pages = [1];
        }
        that.checkall= false;
      }
    })
  }
  // 换页
	changePage(type,index) {
    var pageCount = Math.ceil(this.searchBody.Total / this.searchBody.PageSize);
    if(type=='pre'){
      if(this.searchBody.PageIndex - 1 > 0){
        this.searchBody.PageIndex = this.searchBody.PageIndex - 1;
        this.getUserList();
      }
    }
    if(type=='next') {
      if ((this.searchBody.PageIndex + 1) <= pageCount) {
        this.searchBody.PageIndex = this.searchBody.PageIndex + 1;
        this.getUserList();
      }
    }
    if (type=='first') {
      this.searchBody.PageIndex = 1;
      this.getUserList();
    }
    if (type=='last') {
      this.searchBody.PageIndex = pageCount;
      this.getUserList();
    }
    if (type=='page') {
      this.searchBody.PageIndex = index;
      this.getUserList();
    }
	}
  // 清空查询模版
  clearSearch(){
    this.searchBody.UserId = "";
    this.searchBody.Role = "";
  }
  // 新增
  addUser(){
    let that = this;
    this.userService.addUser(this.addUserModel).subscribe(data=> {
      if (data) {
        window['swal']("成功","新增成功!","success");
        window['$']('#addModel').modal('toggle');
        that.getUserList();
      }
    })
  }
  // 清空新增模版
  clearAddModel(){
    this.addUserModel= {}
  }
  // 编辑
  editUser(){
    let that = this;
    this.userService.editUser(this.editUserModel).subscribe(data=> {
      if (data) {
        window['swal']("成功","更新成功","success");
        window['$']('#editModel').modal('toggle');
        that.getUserList();
      }
    })
  }
  // 删除
  delUser(user){
    let that = this; 
		window["swal"]({
			title: "注意!",
			text: "是否要删除 "+ user.UserId+ " 用户?",
			type: "info",
			confirmButtonText: "确认",
			confirmButtonColor: "#DD6B55",
			cancelButtonText: "取消",
			showCancelButton: true,
			closeOnConfirm: false,
			closeOnCancel: true,
			showLoaderOnConfirm: true
		},
		function(isConfirm) { 
			if(isConfirm){
				that.userService.delUser(user.Id).subscribe(data=> {
					if(data) {
						window["swal"]("成功", "已删除该用户","success");
						that.getUserList();
					}
				})
			} 
		})
  }
  // 多个删除
  delUsers(){
    let that = this;
    let len = window['$']('input[name="checkbox"]:checked');
    if (len.length > 0) {
      window["swal"]({
        title: "确定?",
        text: "确定要删除勾选的用户?",
        type: "info",
        confirmButtonText: "确认",
        confirmButtonColor: "#DD6B55",
        cancelButtonText: "取消",
        showCancelButton: true,
        closeOnConfirm: false,
        closeOnCancel: true,
        showLoaderOnConfirm: true
      },
      function(isConfirm) { 
        if(isConfirm){
          _.forEach(that.userList, item=> {
            if (item.isChecked) {
              that.userService.delUser(item.Id).subscribe(data=> {
                if (data) {
                  window["swal"]("成功", "已删除用户!","success");
                  that.getUserList();
                }
              })
            }
          })
        } 
      })
    }else{
      window["swal"]("注意!", "请勾选要删除的用户!","warning");
    }
  }
  // 弹出模版
  toggleModel(formId,info?){
    if (info) {
      this.editUserModel = _.clone(info);
    }
    let id = "#" + formId;
    window['$'](id).modal('toggle');
  }
  // 全选
  checkAll(){
    if(this.checkall){
      _.forEach(this.userList, item=>{
        item.isChecked= true;
      })
    }else{
      _.forEach(this.userList, item=>{
        item.isChecked= false;
      })
    }
  }
}
