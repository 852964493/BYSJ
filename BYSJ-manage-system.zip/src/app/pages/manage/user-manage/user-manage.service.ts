import { HttpClientService } from '../../../services/http-client.service';
import { Injectable } from '@angular/core';

@Injectable()
export class UserManageService {
    constructor(public httpClient:HttpClientService) { 

    }
    // 获取用户列表
    getUserList(searchBody){
        let postBody:any= {
            pageIndex: searchBody.PageIndex,
            pageSize: parseInt(searchBody.PageSize),
            order: "UserId ASC",
            id: "UserId",
            where:{
                UserId:{
                    "$like": "%"+searchBody.UserId+"%"
                },
                Role:{
                    "$like": "%"+searchBody.Role+"%"
                }
            }
        }
        return this.httpClient.post('api/v1/users/list',postBody);
    }
    // 新增
    addUser(addUserModel){
        return this.httpClient.post('api/v1/users/register',addUserModel);
    }
    // 编辑
    editUser(editUserModel){
        let postBody:any= {
            where:{
                Id: editUserModel.Id
            },
            values: editUserModel
        }
        return this.httpClient.post('api/v1/users/edit',postBody);
    }  
    // 删除
    delUser(Id){
        let postBody:any= {
            Id: Id
        }
        return this.httpClient.post('api/v1/users/del',postBody);
    }
}