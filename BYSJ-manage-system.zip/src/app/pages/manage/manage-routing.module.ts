import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TitleManageComponent } from "./title-manage/title-manage.component";
import { UserManageComponent } from "./user-manage/user-manage.component";
import { StudentManageComponent } from "./student-manage/student-manage.component";
import { TeacherManageComponent } from "./teacher-manage/teacher-manage.component";
import { TaskManageComponent } from "./task-manage/task-manage.component";

const routes: Routes = [
  // {
  //   path: '',
  //   redirectTo: 'student-manage',
  //   pathMatch: 'full'
  // },
  {
    path: "title-manage",
    component:TitleManageComponent
  },
  {
    path: "user-manage",
    component:UserManageComponent
  },
  {
    path: "teacher-manage",
    component:TeacherManageComponent
  },
  {
    path: "student-manage",
    component:StudentManageComponent
  },
  {
    path: "task-manage",
    component:TaskManageComponent
  }
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManageRoutingModule { }
