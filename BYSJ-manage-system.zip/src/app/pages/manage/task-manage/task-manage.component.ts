import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TaskManageService } from "./task-manage.service";
import { Util } from "../../../common/util";
import * as _ from 'lodash';

@Component({
  selector: 'app-task-manage',
  templateUrl: './task-manage.component.html',
  styleUrls: ['./task-manage.component.scss'],
  providers: [TaskManageService]
})
export class TaskManageComponent implements OnInit {
  // 分页
  public pages: any = [];
  // 题目列表
  public taskList:any;
  // 查询模版
  public searchBody:any= {
    StudentId: "",
    StudentName: "",
    PageIndex: 1,
    PageSize: 10,
    Total: ""
  }
  // 新增模版
  public addTaskModel:any= {
    StudentId: "",
    StudentName: ""
  }
  // 显示任务书
  showTaskModel:any= {};
  constructor(
    public TaskService:TaskManageService,
    public util:Util
  ) { 
    this.getTaskList();
  }
  ngOnInit() {

  }
  // 获取任务列表
  getTaskList(index?){
    let that = this;
    if (index) {
      this.searchBody.PageIndex = 1;
    }
    this.TaskService.getTaskList(this.searchBody).subscribe(data=> {
      if (data) {
        that.taskList = data.list;
        that.searchBody.Total = data.total;
        that.searchBody.PageSize = data.pageSize;
        that.searchBody.PageIndex = data.pageIndex;
        if (data.total) {
          that.pages = that.util.setPage(data.total,data.pageSize,data.pageIndex);
        }else{
          // 无数据返回空页
          that.pages = [1];
        }
      }
    })
  }
  // 换页
	changePage(type,index) {
    var pageCount = Math.ceil(this.searchBody.Total / this.searchBody.PageSize);
    if(type=='pre'){
      if(this.searchBody.PageIndex - 1 > 0){
        this.searchBody.PageIndex = this.searchBody.PageIndex - 1;
        this.getTaskList();
      }
    }
    if(type=='next') {
      if ((this.searchBody.PageIndex + 1) <= pageCount) {
        this.searchBody.PageIndex = this.searchBody.PageIndex + 1;
        this.getTaskList();
      }
    }
    if (type=='first') {
      this.searchBody.PageIndex = 1;
      this.getTaskList();
    }
    if (type=='last') {
      this.searchBody.PageIndex = pageCount;
      this.getTaskList();
    }
    if (type=='page') {
      this.searchBody.PageIndex = index;
      this.getTaskList();
    }
  }
  // 清空查询模版
  clearSearch(){
    this.searchBody.StudentId = "";
    this.searchBody.StudentName = "";
  }
  // 新增
  addTask(){
    let that = this;
    this.TaskService.addTask(this.addTaskModel).subscribe(data=> {
      if (data) {
        window['swal']("成功","新增成功!","success");
        window['$']('#addModel').modal('toggle');
        that.getTaskList();
      }
    })
  }
  clearAddModel(){
    this.addTaskModel.StudentId = "";
    this.addTaskModel.StudentName = "";
  }
  // 删除
  delTask(task){
    let that = this; 
		window["swal"]({
			title: "注意!",
			text: "是否要删除 "+ task.StudentName+ " 同学的任务书?",
			type: "info",
			confirmButtonText: "确认",
			confirmButtonColor: "#DD6B55",
			cancelButtonText: "取消",
			showCancelButton: true,
			closeOnConfirm: false,
			closeOnCancel: true,
			showLoaderOnConfirm: true
		},
		function(isConfirm) { 
			if(isConfirm){
				that.TaskService.delTask(task.Id).subscribe(data=> {
					if(data) {
						window["swal"]("成功", "已删除该任务书","success");
						that.getTaskList();
					}
				})
			} 
		})
  }
  // 弹出模版
  toggleModel(formId,info?){
    if (info) {
      this.showTaskModel = _.clone(info);
    }
    let id = "#" + formId;
    window['$'](id).modal('toggle');
  }
}
