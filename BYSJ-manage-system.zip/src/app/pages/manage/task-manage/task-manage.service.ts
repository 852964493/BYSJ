import { HttpClientService } from '../../../services/http-client.service';
import { Injectable } from '@angular/core';

@Injectable()
export class TaskManageService {
    constructor(public httpClient:HttpClientService) { 

    }
    // 获取任务列表
    getTaskList(searchBody){
        let postBody:any= {
            pageIndex: searchBody.PageIndex,
            pageSize: parseInt(searchBody.PageSize),
            order: "StudentId ASC",
            id: "StudentId",
            where:{
                StudentId:{
                    "$like": "%"+searchBody.StudentId+"%"
                },
                StudentName:{
                    "$like": "%"+searchBody.StudentName+"%"
                }
            }
        }
        return this.httpClient.post('api/v1/tasklists/list',postBody);
    }
    // 新增
    addTask(addTaskModel){
        return this.httpClient.post('api/v1/tasklists/add',addTaskModel);
    }
    // 删除
    delTask(Id){
        let postBody:any= {
            Id: Id
        }
        return this.httpClient.post('api/v1/tasklists/del',postBody);
    }

}