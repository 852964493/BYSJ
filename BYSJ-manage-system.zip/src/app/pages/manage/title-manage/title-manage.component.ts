import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TitleManageService } from "./title-manage.service";
import { Util } from "../../../common/util";
import * as _ from 'lodash';

@Component({
  selector: 'app-title-manage',
  templateUrl: './title-manage.component.html',
  styleUrls: ['./title-manage.component.scss'],
  providers: [TitleManageService]
})
export class TitleManageComponent implements OnInit {
  // 全选
  public checkall:any= false;
  // 教师分页
  public teachPages: any = [];
  // 教师列表
  public teachList:any;
  // 教师查询模版
  public teachSearch:any={
    TeacherDepartment: "",
    TeacherName: "",
    PageIndex: 1,
    PageSize: 10,
    Total: ""
  }
  // 分页
  public pages: any = [];
  // 题目列表
  public titleList:any;
  // 查询模版
  public searchBody:any= {
    TitleId: "",
    TitleName: "",
    TeacherName: "",
    PageIndex: 1,
    PageSize: 10,
    Total: ""
  }
  // 新增模版
  public addTitleModel:any= {
    TitleId: "",
    TitleName: "",
    TitleDetail: "",
    TitleRequire: "",
    TitleStatus: "0",
    TeacherName: ""
  }
  // 编辑信息
  public editTitleModel:any= {};
  // 题目详情
  public showTitleDetail:any= {};
  constructor(
    public titleService:TitleManageService,
    public util:Util
  ) {
    this.getTitleList();
  }
  ngOnInit() {

  }
  // 获取题目列表
  getTitleList(index?){
    let that = this;
    if (index) {
      this.searchBody.PageIndex = 1;
    }
    this.titleService.getTitleList(this.searchBody).subscribe(data=> {
      if (data) {
        that.titleList = data.list;
        that.searchBody.Total = data.total;
        that.searchBody.PageSize = data.pageSize;
        that.searchBody.PageIndex = data.pageIndex;
        if (data.total) {
          that.pages = that.util.setPage(data.total,data.pageSize,data.pageIndex);
        }else{
          // 无数据返回空页
          that.pages = [1];
        }
        that.checkall= false;
      }
    })
  }
  // 换页
	changePage(type,index) {
    var pageCount = Math.ceil(this.searchBody.Total / this.searchBody.PageSize);
    if(type=='pre'){
      if(this.searchBody.PageIndex - 1 > 0){
        this.searchBody.PageIndex = this.searchBody.PageIndex - 1;
        this.getTitleList();
      }
    }
    if(type=='next') {
      if ((this.searchBody.PageIndex + 1) <= pageCount) {
        this.searchBody.PageIndex = this.searchBody.PageIndex + 1;
        this.getTitleList();
      }
    }
    if (type=='first') {
      this.searchBody.PageIndex = 1;
      this.getTitleList();
    }
    if (type=='last') {
      this.searchBody.PageIndex = pageCount;
      this.getTitleList();
    }
    if (type=='page') {
      this.searchBody.PageIndex = index;
      this.getTitleList();
    }
	}
  // 清空查询模版
  clearSearch(){
    this.searchBody.TitleId = "";
    this.searchBody.TitleName = "";
    this.searchBody.TeacherName = "";
  }
  // 新增
  addTitle(){
    let that = this;
    this.titleService.addTitle(this.addTitleModel).subscribe(data=> {
      if (data) {
        window['swal']("成功","新增成功!","success");
        window['$']('#addModel').modal('toggle');
        that.getTitleList();
      }
    })
  }
  // 清空新增模版
  clearAddModel(){
    this.addTitleModel= {};
    this.addTitleModel.TitleStatus= "0";
    this.addTitleModel.TeacherName= ""
  }
  // 编辑
  editTitle(){
    let that = this;
    this.titleService.editTitle(this.editTitleModel).subscribe(data=> {
      if (data) {
        window['swal']("成功","更新成功","success");
        window['$']('#editModel').modal('toggle');
        that.getTitleList();
      }
    })
  }
  // 删除
  delTitle(title){
    let that = this; 
		window["swal"]({
			title: "注意!",
			text: "是否要删除 "+ title.TitleName+ " 题目?",
			type: "info",
			confirmButtonText: "确认",
			confirmButtonColor: "#DD6B55",
			cancelButtonText: "取消",
			showCancelButton: true,
			closeOnConfirm: false,
			closeOnCancel: true,
			showLoaderOnConfirm: true
		},
		function(isConfirm) { 
			if(isConfirm){
				that.titleService.delTitle(title.Id).subscribe(data=> {
					if(data) {
						window["swal"]("成功", "已删除该题目","success");
						that.getTitleList();
					}
				})
			} 
		})
  }
  // 题目详情
  showTitle(title){
    this.showTitleDetail = title;
    this.toggleModel('showTitle');
  }
  // 弹出模版
  toggleModel(formId,info?){
    if (info) {
      this.editTitleModel = _.clone(info);
    }
    let id = "#" + formId;
    window['$'](id).modal('toggle');
  }
  // 分配导师
  getTeacherList(type,index?){
    let that = this;
    if (index) {
      this.teachSearch.PageIndex = 1;
    }
    this.titleService.getTeacherList(this.teachSearch).subscribe(data=> {
      if (data) {
        that.teachList = data.list;
        that.teachSearch.Total = data.total;
        that.teachSearch.PageSize = data.pageSize;
        that.teachSearch.PageIndex = data.pageIndex;
        if (data.total) {
          that.teachPages = that.util.setPage(data.total,data.pageSize,data.pageIndex);
        }else{
          // 无数据返回空页
          that.teachPages = [1];
        }
        if(type=='open'){
          that.toggleModel('teachModel');
        }
      }
    })
  }
  // 换页
	teachChangePage(type,index) {
    var pageCount = Math.ceil(this.teachSearch.Total / this.teachSearch.PageSize);
    if(type=='pre'){
      if(this.teachSearch.PageIndex - 1 > 0){
        this.teachSearch.PageIndex = this.teachSearch.PageIndex - 1;
        this.getTeacherList(null,null);
      }
    }
    if(type=='next') {
      if ((this.teachSearch.PageIndex + 1) <= pageCount) {
        this.teachSearch.PageIndex = this.teachSearch.PageIndex + 1;
        this.getTeacherList(null,null);
      }
    }
    if (type=='first') {
      this.teachSearch.PageIndex = 1;
      this.getTeacherList(null,null);
    }
    if (type=='last') {
      this.teachSearch.PageIndex = pageCount;
      this.getTeacherList(null,null);
    }
    if (type=='page') {
      this.teachSearch.PageIndex = index;
      this.getTeacherList(null,null);
    }
  }
  // 清空分配查询模版
  teachClear(){
    this.teachSearch.TeacherName="";
    this.teachSearch.TeacherDepartment="";
    this.teachSearch.pageIndex = 1;
  }
  // 全选
  checkAll(){
    if(this.checkall){
      _.forEach(this.titleList, item=>{
        item.isChecked= true;
      })
    }else{
      _.forEach(this.titleList, item=>{
        item.isChecked= false;
      })
    }
  }
  // 导师分配
  selectTeach(teach){
    let that = this;
    let len=window['$']('input[name="checkbox"]:checked');
    if (len.length>0) {
      window["swal"]({
        title: "确定?",
        text: "确定要将所选题目分配给 "+ teach.TeacherName+ " 导师?",
        type: "info",
        confirmButtonText: "确认",
        confirmButtonColor: "#DD6B55",
        cancelButtonText: "取消",
        showCancelButton: true,
        closeOnConfirm: false,
        closeOnCancel: true,
        showLoaderOnConfirm: true
      },
      function(isConfirm) { 
        if(isConfirm){
          _.forEach(that.titleList, item=>{
            if(item.isChecked){
              that.titleService.selectTeach(item,teach).subscribe(data=>{
                if (data) {
                  window['$']('#teachModel').modal('hide');
                  window["swal"]("成功", "分配成功!","success");
                  that.getTitleList();
                }
              })
            }
          })
        }
      }) 
    }else{
      window["swal"]("注意", "请勾选要分配的题目!","warning");
    }
  }
}
