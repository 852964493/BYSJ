import { HttpClientService } from '../../../services/http-client.service';
import { Injectable } from '@angular/core';

@Injectable()
export class TitleManageService {
    constructor(public httpClient:HttpClientService) { 

    }
    // 获取用户列表
    getTitleList(searchBody){
        let postBody:any= {
            pageIndex: searchBody.PageIndex,
            pageSize: parseInt(searchBody.PageSize),
            order: "TitleId ASC",
            id: "TitleId",
            where:{
                TitleId:{
                    "$like": "%"+searchBody.TitleId+"%"
                },
                TitleName:{
                    "$like": "%"+searchBody.TitleName+"%"
                },
                TeacherName:{
                    "$like": "%"+searchBody.TeacherName+"%"
                }
            }
        }
        return this.httpClient.post('api/v1/titlelists/list',postBody);
    }
    // 新增
    addTitle(addTitleModel){
        return this.httpClient.post('api/v1/titlelists/add',addTitleModel);
    }
    // 编辑
    editTitle(editTitleModel){
        let postBody:any= {
            where:{
                Id: editTitleModel.Id
            },
            values: editTitleModel
        }
        return this.httpClient.post('api/v1/titlelists/edit',postBody);
    }
    // 删除
    delTitle(Id){
        let postBody:any= {
            Id: Id
        }
        return this.httpClient.post('api/v1/titlelists/del',postBody);
    }
    // 获取教师列表
    getTeacherList(teachSearch){
        let postBody:any= {
            pageIndex: teachSearch.PageIndex,
            pageSize: 10,
            order: "TeacherId ASC",
            id: "TeacherId",
            where:{
                TeacherDepartment:{
                    "$like": "%"+teachSearch.TeacherDepartment+"%"
                },
                TeacherName:{
                    "$like": "%"+teachSearch.TeacherName+"%"
                }
            }
        }
        return this.httpClient.post('api/v1/teacherlists/list',postBody);
    }
    // 导师分配
    selectTeach(item,teach){
        let postBody= {
            where:{
                Id: item.Id
            },
            values: {
                TeacherId: teach.TeacherId,
                TeacherName: teach.TeacherName,
                TeacherDepartment: teach.TeacherDepartment
            }
        }
        return this.httpClient.post('api/v1/titlelists/edit',postBody);
    }
}