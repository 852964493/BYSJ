import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TeacherManageService } from "./teacher-manage.service";
import { Util } from "../../../common/util";
import * as _ from 'lodash';

@Component({
  selector: 'app-teacher-manage',
  templateUrl: './teacher-manage.component.html',
  styleUrls: ['./teacher-manage.component.scss'],
  providers: [TeacherManageService]
})
export class TeacherManageComponent implements OnInit {
  // 分页
  public pages: any = [];
  // 导师列表
  public teacherList:any;
  // 查询模版
  public searchBody:any= {
    TeacherDepartment: "",
    TeacherId: "",
    TeacherName: "",
    PageIndex: 1,
    PageSize: 10,
    Total: ""
  }
  // 新增模版
  public addTeacherModel:any= {
    TeacherDepartment: "",
    TeacherId: "",
    TeacherName: "",
    TeacherSex: "",
    TeacherNumber: "",
    TeacherEmail: ""
  }
  // 编辑教师信息
  public editTeacherModel:any= {};

  constructor(
    public teacherService:TeacherManageService,
    public util:Util) 
    { 
    this.getTeacherList();
  }
  ngOnInit() {

  }
  // 获取教师列表
  getTeacherList(index?){
    let that = this;
    if (index) {
      this.searchBody.PageIndex = 1;
    }
    this.teacherService.getTeacherList(this.searchBody).subscribe(data=> {
      if (data) {
        that.teacherList = data.list;
        that.searchBody.Total = data.total;
        that.searchBody.PageSize = data.pageSize;
        that.searchBody.PageIndex = data.pageIndex;
        if (data.total) {
          that.pages = that.util.setPage(data.total,data.pageSize,data.pageIndex);
        }else{
          // 无数据返回空页
          that.pages = [1];
        }
      }
    })
  }
  // 换页
	changePage(type,index) {
    var pageCount = Math.ceil(this.searchBody.Total / this.searchBody.PageSize);
    if(type=='pre'){
      if(this.searchBody.PageIndex - 1 > 0){
        this.searchBody.PageIndex = this.searchBody.PageIndex - 1;
        this.getTeacherList();
      }
    }
    if(type=='next') {
      if ((this.searchBody.PageIndex + 1) <= pageCount) {
        this.searchBody.PageIndex = this.searchBody.PageIndex + 1;
        this.getTeacherList();
      }
    }
    if (type=='first') {
      this.searchBody.PageIndex = 1;
      this.getTeacherList();
    }
    if (type=='last') {
      this.searchBody.PageIndex = pageCount;
      this.getTeacherList();
    }
    if (type=='page') {
      this.searchBody.PageIndex = index;
      this.getTeacherList();
    }
	}
  // 清空查询模版
  clearSearch(){
    this.searchBody.TeacherDepartment = "";
    this.searchBody.TeacherId = "";
    this.searchBody.TeacherName = "";
  }
  // 新增
  addTeacher(){
    let that = this;
    this.teacherService.addTeacher(this.addTeacherModel).subscribe(data=> {
      if (data) {
        window['swal']("成功","新增成功!","success");
        window['$']('#addModel').modal('toggle');
        that.getTeacherList();
      }else{
        window['swal']("失败","新增失败!","error");
      }
    })
  }
  // 清空新增模版
  clearAddModel(){
    this.addTeacherModel= {}
  }
  // 编辑
  editTeacher(){
    let that = this;
    this.teacherService.editTeacher(this.editTeacherModel).subscribe(data=> {
      if (data) {
        window['swal']("成功","更新成功","success");
        window['$']('#editModel').modal('toggle');
        that.getTeacherList();
      }
    })
  }
  // 删除
  delTeacher(teacher){
    let that = this; 
		window["swal"]({
			title: "注意!",
			text: "是否要删除 "+ teacher.TeacherName+ " 导师?",
			type: "info",
			confirmButtonText: "确认",
			confirmButtonColor: "#DD6B55",
			cancelButtonText: "取消",
			showCancelButton: true,
			closeOnConfirm: false,
			closeOnCancel: true,
			showLoaderOnConfirm: true
		},
		function(isConfirm) { 
			if(isConfirm){
				that.teacherService.delTeacher(teacher.TeacherId).subscribe(data=> {
					if(data) {
						window["swal"]("成功", "已删除该导师","success");
						that.getTeacherList();
					}
				})
			} 
		})
  }
  // 弹出模版
  toggleModel(formId,info?){
    if (info) {
      this.editTeacherModel = _.clone(info);
    }
    let id = "#" + formId;
    window['$'](id).modal('toggle');
  }
}
