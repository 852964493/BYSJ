import { HttpClientService } from '../../../services/http-client.service';
import { Injectable } from '@angular/core';

@Injectable()
export class TeacherManageService {
    constructor(public httpClient:HttpClientService) { 

    }
    // 获取教师列表
    getTeacherList(searchBody){
        let postBody:any= {
            pageIndex: searchBody.PageIndex,
            pageSize: parseInt(searchBody.PageSize),
            order: "TeacherId ASC",
            id: "TeacherId",
            where:{
                TeacherDepartment:{
                    "$like": "%"+searchBody.TeacherDepartment+"%"
                },
                TeacherId:{
                    "$like": "%"+searchBody.TeacherId+"%"
                },
                TeacherName:{
                    "$like": "%"+searchBody.TeacherName+"%"
                }
            }
        }
        return this.httpClient.post('api/v1/teacherlists/list',postBody);
    }
    // 新增
    addTeacher(addTeacherModel){
        return this.httpClient.post('api/v1/teacherlists/add',addTeacherModel);
    }
    // 编辑
    editTeacher(editTeacherModel){
        let postBody:any= {
            where:{
                Id: editTeacherModel.Id
            },
            values:editTeacherModel
        }
        return this.httpClient.post('api/v1/teacherlists/edit',postBody);
    }
    // 删除
    delTeacher(Id){
        let postBody:any= {
            Id: Id
        }
        return this.httpClient.post('api/v1/teacherlists/del',postBody);
    }
}