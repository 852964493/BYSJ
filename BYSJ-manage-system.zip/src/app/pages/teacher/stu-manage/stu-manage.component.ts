import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { StuManageService } from "./stu-manage.service";
import { Util } from "../../../common/util";
import * as _ from 'lodash';

@Component({
  selector: 'app-stu-manage',
  templateUrl: './stu-manage.component.html',
  styleUrls: ['./stu-manage.component.scss'],
  providers: [StuManageService]
})
export class StuManageComponent implements OnInit {
  // 教师工号
  public UserId: any;
  // 学生
  public Students: any;
  // 学生信息
  public studentInfo: any = {};
  public taskModel: any = {};
  // 编辑学生模版
  public editStudentModel: any = {};

  constructor(
    public StuService: StuManageService
  ) {
    this.UserId = sessionStorage.getItem('UserId');
    this.getStudents();
  }
  ngOnInit() {
  }
  // 获取学生
  getStudents() {
    let that = this;
    this.StuService.getStudents(this.UserId).subscribe(data => {
      if (data) {
        that.Students = data;
      }
    })
  }
  // 显示学生详情
  showStudent(student) {
    this.studentInfo = student;
    this.toggleModel('studentModel');
  }
  // 显示任务书
  getTask(student) {
    let that = this;
    this.StuService.getTask(student.StudentId).subscribe(data => {
      if (data) {
        that.taskModel = data;
        that.toggleModel('TaskModel');
      }
    })
  }
  // 编辑学生
  editStudent(item) {
    this.editStudentModel = _.clone(item);
    window['$']('#editModel').modal('show');
  }
  // 保存学生
  saveStudent() {
    let that = this;
    this.StuService.saveStudent(this.editStudentModel).subscribe(data => {
      if (data) {
        window['swal']("成功", "更新成功", "success");
        window['$']('#editModel').modal('hide');
        that.getStudents();
      }
    })
  }
  // 弹出模版
  toggleModel(formId) {
    let id = "#" + formId;
    window['$'](id).modal('toggle');
  }
}
