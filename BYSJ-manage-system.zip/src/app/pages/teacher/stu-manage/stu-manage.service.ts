import { HttpClientService } from '../../../services/http-client.service';
import { Injectable } from '@angular/core';

@Injectable()
export class StuManageService {
    constructor(
        public httpClient: HttpClientService
    ) { }
    // 获取学生
    getStudents(useId) {
        let postBody: any = {
            order: "StudentId ASC",
            where: {
                TeacherId: useId
            }
        }
        return this.httpClient.post('api/v1/studentlists/views', postBody);
    }
    // 显示任务书
    getTask(StudentId) {
        let postBody: any = {
            where: {
                StudentId: StudentId
            }
        }
        return this.httpClient.post('api/v1/tasklists/view', postBody);
    }
    // 编辑学生信息
    saveStudent(editstudentModel) {
        let postBody: any = {
            where: {
                Id: editstudentModel.Id
            },
            values: editstudentModel
        }
        return this.httpClient.post('api/v1/studentlists/edit', postBody);
    }
}