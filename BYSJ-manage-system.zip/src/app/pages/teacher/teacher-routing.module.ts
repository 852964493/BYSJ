import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StuManageComponent } from "./stu-manage/stu-manage.component";
import { TieManageComponent } from "./tie-manage/tie-manage.component";

const routes: Routes = [
  // {
  //   path: '',
  //   redirectTo: 'stu-manage',
  //   pathMatch: 'full'
  // },
  {
    path: "stu-manage",
    component:StuManageComponent
  },
  {
    path: "tie-manage",
    component:TieManageComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TeacherRoutingModule { }
