import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from "@angular/forms";
import { TeacherRoutingModule } from './teacher-routing.module';
import { StuManageComponent } from "./stu-manage/stu-manage.component";
import { TieManageComponent } from './tie-manage/tie-manage.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    TeacherRoutingModule
  ],
  declarations: [StuManageComponent, TieManageComponent]
})
export class TeacherModule { }
