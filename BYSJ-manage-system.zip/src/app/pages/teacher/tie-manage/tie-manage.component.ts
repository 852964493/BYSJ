import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TieManageService } from "./tie-manage.service";
import { Util } from "../../../common/util";
import * as _ from 'lodash';

@Component({
  selector: 'app-tie-manage',
  templateUrl: './tie-manage.component.html',
  styleUrls: ['./tie-manage.component.scss'],
  providers: [TieManageService]
})
export class TieManageComponent implements OnInit {
  // 教师工号
  public UserId:any;
  // 题目列表
  public Titles:any;
  // 题目详情
  public titleInfo:any= {};
  constructor(
    public tieService:TieManageService
  ) {
    this.UserId = sessionStorage.getItem('UserId');
    this.getTitles();
  }
  ngOnInit() {
  }
  // 获取题目
  getTitles(){
    let that = this;
    this.tieService.getTitles(this.UserId).subscribe(data=> {
      if (data) {
        that.Titles = data;
      }
    })
  }
  // 确认选题
  subTitle(Title){
    let that = this;
    window["swal"]({
			title: "确定?",
			text: "是否同意 "+Title.StudentName+" 同学选择 "+ Title.TitleName+ " 题目?",
			type: "warning",
			confirmButtonText: "确认",
			confirmButtonColor: "#DD6B55",
			cancelButtonText: "取消",
			showCancelButton: true,
			closeOnConfirm: false,
			closeOnCancel: true,
			showLoaderOnConfirm: true
    },
    function(isConfirm) { 
			if(isConfirm){
        that.tieService.editTitle(Title).subscribe(data=> {
          if (data) {
            that.tieService.editStudent(Title).subscribe(data=> {
              if (data) {
                window['swal']("成功","题目已被选择!","success");
                that.getTitles();
              }
            })
          }
        })
      }
    })
  }
  // 取消选题
  reTitle(Title){
    let that = this;
    window["swal"]({
			title: "确定?",
			text: "是否取消 "+Title.StudentName+" 同学选择 "+ Title.TitleName+ " 题目?",
			type: "warning",
			confirmButtonText: "确认",
			confirmButtonColor: "#DD6B55",
			cancelButtonText: "取消",
			showCancelButton: true,
			closeOnConfirm: false,
			closeOnCancel: true,
			showLoaderOnConfirm: true
    },
    function(isConfirm) { 
			if(isConfirm){
        that.tieService.celTitle(Title).subscribe(data=> {
          if (data) {
            that.tieService.celStudent(Title).subscribe(data=> {
              if (data) {
                window['swal']("已取消","题目已被取消选择!","success");
                that.getTitles();
              }
            })
          }
        })
      }
    })
  }
  // 题目详情
  showDetail(title){
    this.titleInfo = title;
    this.toggleModel('showTitle');
  }
  // 弹出模版
  toggleModel(formId){
    let id = "#" + formId;
    window['$'](id).modal('toggle');
  }
}
