import { HttpClientService } from '../../../services/http-client.service';
import { Injectable } from '@angular/core';

@Injectable()
export class TieManageService {
    constructor(
        public httpClient:HttpClientService
    ) { }
    // 获取题目列表
    getTitles(useId){
        let postBody:any={
            order: "TitleId ASC",
            where: {
                TeacherId: useId
            }
        }
        return this.httpClient.post('api/v1/titlelists/views',postBody);
    }
    // 修改题目状态
    editTitle(Title){
        let postBody:any={
            where: {
                TitleId: Title.TitleId
            },
            values: {
                TitleStatus: "2"
            }
        }
        return this.httpClient.post('api/v1/titlelists/edit',postBody);
    }
    // 修改学生状态
    editStudent(Title){
        let postBody:any={
            where: {
                StudentId: Title.StudentId
            },
            values: {
                SelectStatus: "2",
                TitleId: Title.TitleId,
                TitleName: Title.TitleName
            }
        }
        return this.httpClient.post('api/v1/studentlists/edit',postBody);
    }
    // 取消题目状态
    celTitle(Title){
        let postBody:any={
            where: {
                TitleId: Title.TitleId
            },
            values: {
                TitleStatus: "0",
                StudentId: "",
                StudentName: ""
            }
        }
        return this.httpClient.post('api/v1/titlelists/edit',postBody);
    }
    // 取消学生状态
    celStudent(Title){
        let postBody:any={
            where: {
                StudentId: Title.StudentId
            },
            values: {
                SelectStatus: "0",
                TitleId: "",
                TitleName: ""
            }
        }
        return this.httpClient.post('api/v1/studentlists/edit',postBody);
    }
}