import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TieManageComponent } from './tie-manage.component';

describe('TieManageComponent', () => {
  let component: TieManageComponent;
  let fixture: ComponentFixture<TieManageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TieManageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TieManageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
