import { Component, OnInit, Input } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { environment } from '../../../../environments/environment';
import { LoginComponent } from "../../login/login/login.component";
import * as _ from 'lodash';

@Component({
    selector: 'app-layout',
    templateUrl: './layout.component.html',
    styleUrls: ['./layout.component.scss']
})
export class LayoutComponent implements OnInit {

// Sidebar-Links
public sidebarLinks: Array<any> = [];
public sidebarLinks1: Array<any> = [];
public sidebarLinks2: Array<any> = [];
public sidebarLinks3: Array<any> = [];

public currentUrl: string = "";

public user: any= {};

// sidebar  or   topnav
public layoutMode: String = environment.layout;

constructor(public router: Router) {
    this.user.Role = sessionStorage.getItem('Role');
    this.user.UserId = sessionStorage.getItem('UserId');
    this.user.UserName = sessionStorage.getItem('UserName');
    this.user.updatedAt = sessionStorage.getItem('updatedAt');
    this.router.events.subscribe((evt: NavigationEnd) => {
        this.currentUrl = evt.url;
    });
}

ngOnInit() {
    this.sideBar();
    // 解决footer浮动问题
    window['$'](window).resize();
    let Role = sessionStorage.getItem('Role');
    if (Role == "user") {
        this.sidebarLinks = this.sidebarLinks1;
    } else if(Role == "teach"){
        this.sidebarLinks = this.sidebarLinks2;
    } else{
        this.sidebarLinks = this.sidebarLinks3;
    }
}

//item(open)   subitem(close)
nav(item, subItem?) {
    var currentItem = item;
    if (subItem) {
        currentItem = subItem;
    }
    if (!currentItem.sublinks) {
        if (currentItem.external) {
            if (currentItem.target == '_blank') {
            window.open(currentItem.link);
        } else {
            window.location.href = currentItem.link;
        }
        // 打开新连接
        } else {
            this.router.navigate(currentItem.link);
            var breadcrumbList = _.without([item, subItem], null);
            sessionStorage.setItem('breadcrumbList', JSON.stringify(breadcrumbList));
        }
    }
}

  sideBar(){
    // student
    this.sidebarLinks1 = [
      // {
      //   'title': 'Home',
      //   'icon': 'home',
      //   'link': ['/pages/first/home']
      // },
      {
        'title': '选题',
        'icon': 'legal',
        'link': ['/pages/student/select-title']
      },
      {
        'title': '个人信息',
        'icon': 'user',
        'link': ['/pages/student/account-info']
      },
      {
        'title': '任务书',
        'icon': 'list-ol',
        'link': ['/pages/student/plan-progress']
      },
      // {
      //   'title': '导师上传',
      //   'icon': 'upload',
      //   'link': ['/pages/student/teacher-upload']
      // },
      {
        'title': '公告',
        'icon': 'newspaper-o',
        'link': ['/pages/notices/notice']
      }
      // {
      //   'title': 'Demo',
      //   'icon': 'plus-square',
      //   'link': ['/pages/demoManage/list']
      // }
    ];

    // teacher
    this.sidebarLinks2 = [
      // {
      //   'title': 'Home',
      //   'icon': 'home',
      //   'link': ['/pages/first/home']
      // },
      // {
      //   'title': '最新消息',
      //   'icon': 'repeat',
      //   'link': ['/pages/news/new']
      // },
      {
        'title': '学生管理',
        'icon': 'mortar-board',
        'link': ['/pages/teacher/stu-manage']
      },
      {
        'title': '选题管理',
        'icon': 'map',
        'link': ['/pages/teacher/tie-manage']
      },
      {
        'title': '公告',
        'icon': 'newspaper-o',
        'link': ['/pages/notices/notice']
      }
    ];

    // manage
    this.sidebarLinks3 = [
      // {
      //   'title': 'Home',
      //   'icon': 'home',
      //   'link': ['/pages/first/home']
      // },
      // {
      //   'title': '最新消息',
      //   'icon': 'repeat',
      //   'link': ['/pages/news/new']
      // },
      {
        'title': '用户管理',
        'icon': 'users',
        'link': ['/pages/manage/user-manage']
      },
      {
        'title': '题目管理',
        'icon': 'map',
        'link': ['/pages/manage/title-manage']
      },
      {
        'title': '导师管理',
        'icon': 'leaf',
        'link': ['/pages/manage/teacher-manage']
      },
      {
        'title': '学生管理',
        'icon': 'graduation-cap',
        'link': ['/pages/manage/student-manage']
      },
      {
        'title': '任务书管理',
        'icon': 'list',
        'link': ['/pages/manage/task-manage']
      },
      {
        'title': '公告',
        'icon': 'newspaper-o',
        'link': ['/pages/notices/notice']
      }
      // {
      //   'title': 'Demo',
      //   'icon': 'plus-square',
      //   'link': ['/pages/demoManage/list']
      // }
    ];

  }
}
