import { HttpClientService } from '../../../services/http-client.service';
import { Injectable } from '@angular/core';

@Injectable()
export class NoticeService {
    constructor(public httpClient: HttpClientService) {

    }
    // 获取公告
    getNotice() {
        let postBody: any = {
            where: {
                Id: 1
            }
        }
        return this.httpClient.post('api/v1/notices/view', postBody);
    }
    // 编辑公告
    editNotices(editInfo) {
        let postBody: any = {
            where: {
                Id: 1
            },
            values: editInfo
        }
        return this.httpClient.post('api/v1/notices/edit', postBody);
    }
}