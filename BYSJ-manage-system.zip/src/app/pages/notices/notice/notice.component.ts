import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NoticeService } from "./notice.service";
import * as _ from 'lodash';

@Component({
  selector: 'app-notice',
  templateUrl: './notice.component.html',
  styleUrls: ['./notice.component.scss'],
  providers: [NoticeService]
})
export class NoticeComponent implements OnInit {
  // 登录权限
  public role: any;
  // 公告详情
  public noticesInfo: any = {};
  // 编辑状态
  public editStatus: any = '1';
  // 编辑模版信息
  public editNoticesInfo: any = {};

  constructor(
    public noticeService: NoticeService
  ) {
    this.role = sessionStorage.getItem('Role');
    this.getNotices();
  }

  ngOnInit() {

  }
  // 获取公告详情
  getNotices() {
    let that = this;
    this.noticeService.getNotice().subscribe(data => {
      if (data) {
        console.log(data)
        that.noticesInfo = data;
      }
    })
  }
  // 编辑公告
  editNotices() {
    this.editStatus = '2';
    this.editNoticesInfo = _.clone(this.noticesInfo);
  }
  // 保存公告
  saveNotices() {
    let that = this;
    this.noticeService.editNotices(this.editNoticesInfo).subscribe(data => {
      if (data) {
        window["swal"]("成功", "编辑成功!", "success");
        that.getNotices();
        that.editStatus = '1';
      }
    })
  }
  // 取消公告
  celNotices() {
    this.editStatus = '1';
  }
}
