import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from "@angular/forms";
import { NoticeRoutingModule } from './notice-routing.module';
import { NoticeComponent } from './notice/notice.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    NoticeRoutingModule
  ],
  declarations: [NoticeComponent]
})
export class NoticeModule { }
