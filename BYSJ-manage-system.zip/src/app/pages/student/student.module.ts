import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from "@angular/forms";

import { StudentRoutingModule } from "./student-routing.module";
import { AccountInfoComponent } from "./account-info/account-info.component";
import { SelectTitleComponent } from "./select-title/select-title.component";
import { TeacherUploadComponent } from "./teacher-upload/teacher-upload.component";
import { PlanProgressComponent } from './plan-progress/plan-progress.component';

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    StudentRoutingModule
  ],
  declarations: [
    AccountInfoComponent,
    SelectTitleComponent,
    TeacherUploadComponent, 
    PlanProgressComponent
  ]
})
export class StudentModule { }
