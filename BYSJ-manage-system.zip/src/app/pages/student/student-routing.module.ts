import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AccountInfoComponent } from "./account-info/account-info.component";
import { SelectTitleComponent } from "./select-title/select-title.component";
import { TeacherUploadComponent } from "./teacher-upload/teacher-upload.component";
import { PlanProgressComponent } from "./plan-progress/plan-progress.component";

const routes: Routes = [
  // {
  //   path: '',
  //   redirectTo: 'select-title',
  //   pathMatch: 'full'
  // },
  {
    path: "account-info",
    component:AccountInfoComponent
  },
  {
    path: "plan-progress",
    component:PlanProgressComponent
  },
  {
    path: "select-title",
    component:SelectTitleComponent
  },
  {
    path: "teacher-upload",
    component:TeacherUploadComponent
  }
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StudentRoutingModule { }
