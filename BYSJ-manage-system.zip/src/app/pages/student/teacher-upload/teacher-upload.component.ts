import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teacher-upload',
  templateUrl: './teacher-upload.component.html',
  styleUrls: ['./teacher-upload.component.scss']
})
export class TeacherUploadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
