import { HttpClientService } from '../../../services/http-client.service';
import { Injectable } from '@angular/core';

@Injectable()
export class PlanProgressService {
    constructor(public httpClient:HttpClientService) { 

    }
    // 获取任务书
    getTask(UserId){
        let postBody:any= {
            where:{
                StudentId: UserId
            }
        }
        return this.httpClient.post('api/v1/tasklists/view',postBody);
    }
    // 编辑
    editTask(EditTaskModel){
        let postBody:any= {
            where:{
                Id: EditTaskModel.Id
            },
            values: EditTaskModel
        }
        return this.httpClient.post('api/v1/tasklists/edit',postBody);
    }
}