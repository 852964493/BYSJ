import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanProgressComponent } from './plan-progress.component';

describe('PlanProgressComponent', () => {
  let component: PlanProgressComponent;
  let fixture: ComponentFixture<PlanProgressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlanProgressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanProgressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
