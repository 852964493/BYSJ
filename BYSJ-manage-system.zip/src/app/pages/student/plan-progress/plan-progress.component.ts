import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PlanProgressService } from './plan-progress.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-plan-progress',
  templateUrl: './plan-progress.component.html',
  styleUrls: ['./plan-progress.component.scss'],
  providers: [PlanProgressService]
})
export class PlanProgressComponent implements OnInit {
  // 是否为编辑状态
  public isEditStatus:any= false;
  // 用户ID
  public UserId:any;
  // 任务书
  public Task:any= {};
  // 任务书编辑
  public TaskEditModel:any= {};
  constructor(
    public PlanService:PlanProgressService
  ) {
    this.UserId = sessionStorage.getItem('UserId');
    this.getTask();
  }
  ngOnInit() {
    window['$']('#slider').slider({
      min:0,
      max:100,
      step:1,
      orientation:'horizontal',
      value:80,
      range:false,
      handle:'round',
      enabled:true
    });
  }
  // 获取任务书
  getTask(){
    let that = this;
    this.PlanService.getTask(this.UserId).subscribe(data=> {
      if (data) {
        that.Task = data;
      }
    })
  }
  // 跳到编辑
  goEdit(){
    this.isEditStatus = true;
    this.TaskEditModel = _.clone(this.Task);
  }
  // 取消编辑
  goBack(){
    this.isEditStatus = false;
  }
  // 编辑
  editTask(){
    let that = this;
    this.PlanService.editTask(this.TaskEditModel).subscribe(data=> {
      if (data) {
        window['swal']("成功","编辑成功!","success");
        that.getTask();
        that.goBack();
      }
    })
  }
  // 查看任务书例子
  showTaskDemo(){
    this.toggleModel('DemoModel');
  }
  // 弹出模版
  toggleModel(formId){
    let id = "#" + formId;
    window['$'](id).modal('toggle');
  }
}
