import { HttpClientService } from '../../../services/http-client.service';
import { Injectable } from '@angular/core';

@Injectable()
export class SelectTitleService {
    constructor(public httpClient:HttpClientService) { 

    }
    // 获取题目信息
    getTitle(StudentId){
        let postBody:any={
            where: {
                StudentId: StudentId
            }
        }
        return this.httpClient.post('api/v1/titlelists/view',postBody);
    }
    // 获取题目列表
    getTitles(TeacherId){
        let postBody:any={
            order: "TitleId ASC",
            where: {
                TeacherId: TeacherId
            }
        }
        return this.httpClient.post('api/v1/titlelists/views',postBody);
    }
    // 获取学生信息
    getStudent(StudentId){
        let postBody:any={
            where: {
                StudentId: StudentId
            }
        }
        return this.httpClient.post('api/v1/studentlists/view',postBody);
    }
    // 修改题目状态
    editTitle(title,student){
        let postBody:any= {
            where: {
                TitleId: title.TitleId
            },
            values: {
                TitleStatus: "1",
                StudentId: student.StudentId,
                StudentName: student.StudentName
            }
        }
        return this.httpClient.post('api/v1/titlelists/edit',postBody);
    }
    // 修改学生状态
    editStudent(student){
        let postBody:any= {
            where: {
                StudentId: student.StudentId
            },
            values: {
                SelectStatus: "1",
            }
        }
        return this.httpClient.post('api/v1/studentlists/edit',postBody);
    }
    // 取消题目状态
    celTitle(Title){
        let postBody:any= {
            where: {
                TitleId: Title.TitleId
            },
            values: {
                TitleStatus: "0",
                StudentId: "",
                StudentName: ""
            }
        }
        return this.httpClient.post('api/v1/titlelists/edit',postBody);
    }
    // 取消学生状态
    celStudent(Title){
        let postBody:any= {
            where: {
                StudentId: Title.StudentId
            },
            values: {
                SelectStatus: "0",
            }
        }
        return this.httpClient.post('api/v1/studentlists/edit',postBody);
    }
}