import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SelectTitleService } from './select-title.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-select-title',
  templateUrl: './select-title.component.html',
  styleUrls: ['./select-title.component.scss'],
  providers: [SelectTitleService]
})
export class SelectTitleComponent implements OnInit {
  // 学生学号
  public StudentId:any;
  // 学生信息
  public Student:any= {};
  // 教师工号
  public TeacherId:any;
  // 题目信息
  public Title:any= {};
  // 题目列表
  public Titles:any;
  // 题目详情
  public titleInfo:any= {};
  constructor( 
    public selectService:SelectTitleService
  ) { 
    this.TeacherId = sessionStorage.getItem('TeacherId');
    this.StudentId = sessionStorage.getItem('UserId');
    this.getTitle();
    this.getTitles();
    this.getStudent();
  }
  ngOnInit() {

  }
  // 获取题目信息
  getTitle(){
    let that = this;
    this.selectService.getTitle(this.StudentId).subscribe(data=> {
      if (data) {
        that.Title = data;
      }
    })
  }
  // 获取题目列表
  getTitles(){
    let that = this;
    this.selectService.getTitles(this.TeacherId).subscribe(data=> {
      if (data) {
        that.Titles = data;
      }
    })
  }
  // 获取学生信息
  getStudent(){
    let that = this;
    this.selectService.getStudent(this.StudentId).subscribe(data=> {
      if (data) {
        that.Student = data;
      }
    })
  }
  // 选择题目
  selTitle(tle){
    let that = this;
    window["swal"]({
			title: "确定?",
			text: "确定要选择 "+ tle.TitleName+ " 题目?",
			type: "warning",
			confirmButtonText: "确认",
			confirmButtonColor: "#DD6B55",
			cancelButtonText: "取消",
			showCancelButton: true,
			closeOnConfirm: false,
			closeOnCancel: true,
			showLoaderOnConfirm: true
		},
		function(isConfirm) { 
			if(isConfirm){
        that.selectService.editTitle(tle,that.Student).subscribe(data=> {
          if (data) {
            that.selectService.editStudent(that.Student).subscribe(data=> {
              if (data) {
                window['swal']("等待...","选择成功，请等待确认通过...","warning");
                that.getTitle();
                that.getStudent();
                that.getTitles();
              }
            })
          }
        })
			} 
		})
  }
  // 取消选择
  cancel(){
    let that = this;
    window["swal"]({
			title: "确定?",
			text: "确定要取消 "+ this.Title.TitleName+ " 题目?",
			type: "warning",
			confirmButtonText: "确认",
			confirmButtonColor: "#DD6B55",
			cancelButtonText: "取消",
			showCancelButton: true,
			closeOnConfirm: false,
			closeOnCancel: true,
			showLoaderOnConfirm: true
    },
    function(isConfirm) { 
			if(isConfirm){
        that.selectService.celTitle(that.Title).subscribe(data=> {
          if (data) {
            that.selectService.celStudent(that.Title).subscribe(data=> {
              if (data) {
                window['swal']("已取消选择","请重新选择题目...","info");
                that.getTitle();
                that.getStudent();
                that.getTitles();
              }
            })
          }
        })
			} 
		})
  }
  // 题目详情
  showDetail(title){
    this.titleInfo = title;
    this.toggleModel('showTitle');
  }
  // 弹出模版
  toggleModel(formId){
    let id = "#" + formId;
    window['$'](id).modal('toggle');
  }
}
