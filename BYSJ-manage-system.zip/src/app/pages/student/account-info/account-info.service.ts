import { HttpClientService } from '../../../services/http-client.service';
import { Injectable } from '@angular/core';

@Injectable()
export class AccountInfoService {
    constructor(public httpClient: HttpClientService) {

    }
    // 获取学生
    getStudent(StudentId) {
        let postBody: any = {
            where: {
                StudentId: StudentId
            }
        }
        return this.httpClient.post('api/v1/studentlists/view', postBody);
    }
    // 获取题目信息
    getTitle(TitleId) {
        let postBody: any = {
            where: {
                TitleId: TitleId
            }
        }
        return this.httpClient.post('api/v1/titlelists/view', postBody);
    }
    // 编辑关键字
    editKeyWord(editModel) {
        let postBody: any = {
            where: {
                Id: editModel.Id
            },
            values: editModel
        }
        return this.httpClient.post('api/v1/studentlists/edit', postBody);
    }
}