import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AccountInfoService } from './account-info.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-account-info',
  templateUrl: './account-info.component.html',
  styleUrls: ['./account-info.component.scss'],
  providers: [AccountInfoService]
})
export class AccountInfoComponent implements OnInit {
  public UserId: any;
  public Student: any = {};
  public Title: any = {};
  public EditModel: any = {};

  constructor(public accountInfoService: AccountInfoService) {
    this.UserId = sessionStorage.getItem('UserId');
    this.getStudent();
  }
  ngOnInit() {

  }
  // 获取学生信息
  getStudent() {
    let that = this;
    this.accountInfoService.getStudent(this.UserId).subscribe(data => {
      if (data) {
        that.Student = data;
      }
    })
  }
  // 显示题目信息
  showTitle() {
    let that = this;
    this.accountInfoService.getTitle(this.Student.TitleId).subscribe(data => {
      if (data) {
        that.Title = data;
        that.toggleModel('TitleModel', null);
      }
    })
  }
  // 编辑关键字
  editKeyWord() {
    let that = this;
    this.accountInfoService.editKeyWord(this.EditModel).subscribe(data => {
      if (data) {
        window["swal"]("成功", "编辑成功!", "success");
        window['$']('#KeyWordModel').modal('toggle');
        that.getStudent();
      }
    })
  }
  // 弹出模版
  toggleModel(formId, index?) {
    if (index) {
      this.EditModel = _.clone(this.Student);
    }
    let id = "#" + formId;
    window['$'](id).modal('toggle');
  }
}
