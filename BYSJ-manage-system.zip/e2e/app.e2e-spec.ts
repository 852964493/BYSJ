import { LegionOtcWebPage } from './app.po';

describe('BS-system App', () => {
  let page: LegionOtcWebPage;

  beforeEach(() => {
    page = new LegionOtcWebPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
